/**
 * withNotificationListener.js
 * Adds the ShieldNotificationListenerService used by Message Guard to scan
 * incoming SMS / app notifications for scam keywords and malicious URLs.
 *
 * Android 13/14/15 compliance:
 *  - android:exported="true" (required bound system service)
 *  - android:directBootAware="true"
 *  - BIND_NOTIFICATION_LISTENER_SERVICE permission declared
 */
const { withAndroidManifest, withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const LISTENER_JAVA = `package PACKAGE_NAME;

import android.content.Context;
import android.content.Intent;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

/**
 * Message Guard engine.
 * Listens for every posted notification (SMS apps, messengers, banks)
 * and runs scam-keyword + URL heuristics on the text.
 */
public class ShieldNotificationListener extends NotificationListenerService {
    private static final String TAG = "ShieldNotifListener";

    private static final String[] SCAM_KEYWORDS = {
        "lottery", "winner", "prize", "claim your", "verify your account",
        "account suspended", "click here", "urgent action", "bank alert",
        "otp", "password", "refund", "package delivery", "you have won",
        "free gift", "limited time", "immediately"
    };

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) {
            return;
        }
        CharSequence title = sbn.getNotification().extras.getCharSequence(
                android.app.Notification.EXTRA_TITLE);
        CharSequence text = sbn.getNotification().extras.getCharSequence(
                android.app.Notification.EXTRA_TEXT);
        String body = (text == null ? "" : text.toString()).toLowerCase();
        Log.i(TAG, "Message Guard: notification from " + sbn.getPackageName());

        if (isScam(body)) {
            Log.w(TAG, "Message Guard: SCAM pattern detected - notifying threat engine");
            Intent alert = new Intent("com.macybershield.THREAT_DETECTED");
            alert.putExtra("guard", "message");
            alert.putExtra("source", sbn.getPackageName());
            sendBroadcast(alert);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // No action needed
    }

    private static boolean isScam(String text) {
        if (text == null || text.isEmpty()) {
            return false;
        }
        for (String keyword : SCAM_KEYWORDS) {
            if (text.contains(keyword)) {
                return true;
            }
        }
        return false;
    }
}
`;

function ensurePermission(manifest, name) {
  manifest['uses-permission'] = manifest['uses-permission'] || [];
  const exists = manifest['uses-permission'].some(
    (p) => p.$ && p.$['android:name'] === name
  );
  if (!exists) {
    manifest['uses-permission'].push({ $: { 'android:name': name } });
  }
}

module.exports = function withNotificationListener(config) {
  config = withAndroidManifest(config, async (config) => {
    const manifest = config.modResults.manifest;
    ensurePermission(manifest, 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE');

    const application = manifest.application[0];
    application.service = application.service || [];
    application.service.push({
      $: {
        'android:name': '.ShieldNotificationListener',
        'android:exported': 'true',
        'android:permission': 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE',
        'android:directBootAware': 'true',
      },
      'intent-filter': [
        {
          action: [
            {
              $: {
                'android:name': 'android.service.notification.NotificationListenerService',
              },
            },
          ],
        },
      ],
    });
    return config;
  });

  config = withDangerousMod(config, [
    'android',
    async (config) => {
      const pkg = (config.android && config.android.package) || 'com.macybershield';
      const javaRoot = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'java',
        ...pkg.split('.')
      );
      fs.mkdirSync(javaRoot, { recursive: true });
      fs.writeFileSync(
        path.join(javaRoot, 'ShieldNotificationListener.java'),
        LISTENER_JAVA.split('PACKAGE_NAME').join(pkg)
      );
      return config;
    },
  ]);

  return config;
};
