/**
 * MA CYBER SHIELD - Main Expo Config Plugin
 * Composes all modular native Android plugins.
 * Run `npx expo prebuild --platform android --clean` to generate
 * the native Android project with all services, receivers and permissions.
 */
const withDeviceAdmin = require('./withDeviceAdmin');
const withAccessibility = require('./withAccessibility');
const withUsageStats = require('./withUsageStats');
const withForegroundService = require('./withForegroundService');
const withNotificationListener = require('./withNotificationListener');
const withBootReceiver = require('./withBootReceiver');

module.exports = function cyberShieldPlugin(config) {
  // 1. Persistent 24/7 Foreground Service (SPECIAL_USE, directBootAware)
  config = withForegroundService(config);
  // 2. Accessibility Service (WebView/link interception)
  config = withAccessibility(config);
  // 3. Notification Listener (SMS / app notification scanning)
  config = withNotificationListener(config);
  // 4. Boot Receiver (restarts protection after reboot)
  config = withBootReceiver(config);
  // 5. Usage Stats permission (App Guard risk analysis)
  config = withUsageStats(config);
  // 6. Device Admin receiver (optional theft protection)
  config = withDeviceAdmin(config);
  return config;
};
