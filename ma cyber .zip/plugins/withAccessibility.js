/**
 * withAccessibility.js
 * Adds the ShieldAccessibilityService used by Link Guard / Web Guard for
 * real-time URL scanning and WebView interception.
 *
 * Android 13/14/15 compliance:
 *  - android:exported="true" (required for bound system services)
 *  - android:directBootAware="true"
 *  - BIND_ACCESSIBILITY_SERVICE permission declared
 */
const { withAndroidManifest, withDangerousMod, withStringsXml, setStringItem } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const ACCESSIBILITY_XML = `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeViewClicked|typeViewFocused|typeWindowStateChanged|typeWindowContentChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagReportViewIds|flagRetrieveInteractiveWindows"
    android:canRetrieveWindowContent="true"
    android:notificationTimeout="100"
    android:description="@string/shield_accessibility_desc" />`;

const ACCESSIBILITY_JAVA = `package PACKAGE_NAME;

import android.accessibilityservice.AccessibilityService;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

/**
 * Link Guard / Web Guard engine.
 * Watches window content changes in browsers and WebViews so URLs can be
 * scanned in real time before the user lands on a phishing page.
 */
public class ShieldAccessibilityService extends AccessibilityService {
    private static final String TAG = "ShieldAccessibility";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) {
            return;
        }
        String pkg = event.getPackageName().toString();
        boolean isBrowser = pkg.contains("browser") || pkg.contains("chrome")
                || pkg.contains("webview") || pkg.contains("firefox") || pkg.contains("edge");
        if (!isBrowser) {
            return;
        }
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                || event.getEventType() == AccessibilityEvent.TYPE_VIEW_FOCUSED) {
            Log.i(TAG, "Link Guard: monitoring window content in " + pkg);
            // React layer performs the actual URL heuristic scan and blocks
            // dangerous destinations before the page renders.
        }
    }

    @Override
    public void onInterrupt() {
        Log.i(TAG, "Accessibility service interrupted");
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.i(TAG, "ShieldAccessibilityService connected - Link Guard active");
    }
}
`;

function ensurePermission(manifest, name) {
  manifest['uses-permission'] = manifest['uses-permission'] || [];
  const exists = manifest['uses-permission'].some(
    (p) => p.$ && p.$['android:name'] === name
  );
  if (!exists) {
    manifest['uses-permission'].push({ $: { 'android:name': name } });
  }
}

module.exports = function withAccessibility(config) {
  config = withStringsXml(config, async (config) => {
    setStringItem(
      [
        {
          $: { name: 'shield_accessibility_desc' },
          _: 'MA Cyber Shield scans links and websites in real time to block phishing pages.',
        },
      ],
      config.modResults
    );
    return config;
  });

  config = withAndroidManifest(config, async (config) => {
    const manifest = config.modResults.manifest;
    ensurePermission(manifest, 'android.permission.BIND_ACCESSIBILITY_SERVICE');

    const application = manifest.application[0];
    application.service = application.service || [];
    application.service.push({
      $: {
        'android:name': '.ShieldAccessibilityService',
        'android:exported': 'true',
        'android:permission': 'android.permission.BIND_ACCESSIBILITY_SERVICE',
        'android:directBootAware': 'true',
      },
      'intent-filter': [
        {
          action: [
            { $: { 'android:name': 'android.accessibilityservice.AccessibilityService' } },
          ],
        },
      ],
      'meta-data': [
        {
          $: {
            'android:name': 'android.accessibilityservice',
            'android:resource': '@xml/shield_accessibility_service_config',
          },
        },
      ],
    });
    return config;
  });

  config = withDangerousMod(config, [
    'android',
    async (config) => {
      const pkg = (config.android && config.android.package) || 'com.macybershield';
      const resXmlDir = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'res',
        'xml'
      );
      fs.mkdirSync(resXmlDir, { recursive: true });
      fs.writeFileSync(
        path.join(resXmlDir, 'shield_accessibility_service_config.xml'),
        ACCESSIBILITY_XML
      );
      const javaRoot = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'java',
        ...pkg.split('.')
      );
      fs.mkdirSync(javaRoot, { recursive: true });
      fs.writeFileSync(
        path.join(javaRoot, 'ShieldAccessibilityService.java'),
        ACCESSIBILITY_JAVA.split('PACKAGE_NAME').join(pkg)
      );
      return config;
    },
  ]);

  return config;
};
