/**
 * withBootReceiver.js
 * Restarts the 24/7 ShieldForegroundService automatically after the device
 * boots (LOCKED_BOOT_COMPLETED covers direct-boot / locked-device starts).
 *
 * Android 13/14/15 compliance:
 *  - android:exported="true" with explicit BOOT_COMPLETED intent filter
 *  - android:directBootAware="true"
 */
const { withAndroidManifest, withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const BOOT_JAVA = `package PACKAGE_NAME;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/** Restarts 24/7 protection after the device reboots (even before first unlock). */
public class ShieldBootReceiver extends BroadcastReceiver {
    private static final String TAG = "ShieldBootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) {
            return;
        }
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || "android.intent.action.LOCKED_BOOT_COMPLETED".equals(action)) {
            Log.i(TAG, "Boot received (" + action + ") - restarting protection service");
            Intent service = new Intent(context, ShieldForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        }
    }
}
`;

function ensurePermission(manifest, name) {
  manifest['uses-permission'] = manifest['uses-permission'] || [];
  const exists = manifest['uses-permission'].some(
    (p) => p.$ && p.$['android:name'] === name
  );
  if (!exists) {
    manifest['uses-permission'].push({ $: { 'android:name': name } });
  }
}

module.exports = function withBootReceiver(config) {
  config = withAndroidManifest(config, async (config) => {
    const manifest = config.modResults.manifest;
    ensurePermission(manifest, 'android.permission.RECEIVE_BOOT_COMPLETED');

    const application = manifest.application[0];
    application.receiver = application.receiver || [];
    application.receiver.push({
      $: {
        'android:name': '.ShieldBootReceiver',
        'android:exported': 'true',
        'android:directBootAware': 'true',
        'android:enabled': 'true',
      },
      'intent-filter': [
        {
          action: [
            { $: { 'android:name': 'android.intent.action.BOOT_COMPLETED' } },
            { $: { 'android:name': 'android.intent.action.LOCKED_BOOT_COMPLETED' } },
          ],
        },
      ],
    });
    return config;
  });

  config = withDangerousMod(config, [
    'android',
    async (config) => {
      const pkg = (config.android && config.android.package) || 'com.macybershield';
      const javaRoot = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'java',
        ...pkg.split('.')
      );
      fs.mkdirSync(javaRoot, { recursive: true });
      fs.writeFileSync(
        path.join(javaRoot, 'ShieldBootReceiver.java'),
        BOOT_JAVA.split('PACKAGE_NAME').join(pkg)
      );
      return config;
    },
  ]);

  return config;
};
