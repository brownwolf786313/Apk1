/**
 * withDeviceAdmin.js (OPTIONAL)
 * Adds a DeviceAdminReceiver for theft protection (remote lock / wipe).
 * The receiver is declared but only becomes active when the user explicitly
 * grants Device Admin from the app's Protection Settings screen.
 *
 * Android 13/14/15 compliance:
 *  - android:exported="true" with explicit DEVICE_ADMIN_ENABLED intent filter
 *  - android:directBootAware="true"
 */
const { withAndroidManifest, withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const DEVICE_ADMIN_XML = `<?xml version="1.0" encoding="utf-8"?>
<device-admin xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-policies>
        <force-lock />
        <wipe-data />
        <expire-password />
        <watch-login />
    </uses-policies>
</device-admin>`;

const DEVICE_ADMIN_JAVA = `package PACKAGE_NAME;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/** Optional theft-protection receiver. Activated only when the user grants
 *  Device Admin from Protection Settings. */
public class ShieldDeviceAdminReceiver extends DeviceAdminReceiver {
    private static final String TAG = "ShieldDeviceAdmin";

    @Override
    public void onEnabled(Context context, Intent intent) {
        Log.i(TAG, "Device admin granted - theft protection active");
        super.onEnabled(context, intent);
    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "Disabling MA CYBER SHIELD device admin will stop theft-protection features.";
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        Log.i(TAG, "Device admin revoked");
        super.onDisabled(context, intent);
    }
}
`;

function ensurePermission(manifest, name) {
  manifest['uses-permission'] = manifest['uses-permission'] || [];
  const exists = manifest['uses-permission'].some(
    (p) => p.$ && p.$['android:name'] === name
  );
  if (!exists) {
    manifest['uses-permission'].push({ $: { 'android:name': name } });
  }
}

module.exports = function withDeviceAdmin(config) {
  config = withAndroidManifest(config, async (config) => {
    const manifest = config.modResults.manifest;
    ensurePermission(manifest, 'android.permission.BIND_DEVICE_ADMIN');

    const application = manifest.application[0];
    application.receiver = application.receiver || [];
    application.receiver.push({
      $: {
        'android:name': '.ShieldDeviceAdminReceiver',
        'android:exported': 'true',
        'android:directBootAware': 'true',
        'android:permission': 'android.permission.BIND_DEVICE_ADMIN',
      },
      'meta-data': [
        {
          $: {
            'android:name': 'android.app.device_admin',
            'android:resource': '@xml/shield_device_admin_receiver',
          },
        },
      ],
      'intent-filter': [
        {
          action: [
            { $: { 'android:name': 'android.app.action.DEVICE_ADMIN_ENABLED' } },
          ],
        },
      ],
    });
    return config;
  });

  config = withDangerousMod(config, [
    'android',
    async (config) => {
      const pkg = (config.android && config.android.package) || 'com.macybershield';
      const resXmlDir = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'res',
        'xml'
      );
      fs.mkdirSync(resXmlDir, { recursive: true });
      fs.writeFileSync(
        path.join(resXmlDir, 'shield_device_admin_receiver.xml'),
        DEVICE_ADMIN_XML
      );
      const javaRoot = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'java',
        ...pkg.split('.')
      );
      fs.mkdirSync(javaRoot, { recursive: true });
      fs.writeFileSync(
        path.join(javaRoot, 'ShieldDeviceAdminReceiver.java'),
        DEVICE_ADMIN_JAVA.split('PACKAGE_NAME').join(pkg)
      );
      return config;
    },
  ]);

  return config;
};
