/**
 * withUsageStats.js
 * Declares PACKAGE_USAGE_STATS so App Guard can analyse installed apps and
 * usage patterns for risk scoring. The user grants this from system settings.
 */
const { withAndroidManifest } = require('@expo/config-plugins');

function ensurePermission(manifest, name) {
  manifest['uses-permission'] = manifest['uses-permission'] || [];
  const exists = manifest['uses-permission'].some(
    (p) => p.$ && p.$['android:name'] === name
  );
  if (!exists) {
    manifest['uses-permission'].push({ $: { 'android:name': name } });
  }
}

module.exports = function withUsageStats(config) {
  return withAndroidManifest(config, async (config) => {
    const manifest = config.modResults.manifest;
    ensurePermission(manifest, 'android.permission.PACKAGE_USAGE_STATS');
    return config;
  });
};
