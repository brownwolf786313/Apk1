import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

import HomeScreen from '../screens/HomeScreen';
import DashboardScreen from '../screens/DashboardScreen';
import AlertsScreen from '../screens/AlertsScreen';
import HistoryScreen from '../screens/HistoryScreen';
import SettingsScreen from '../screens/SettingsScreen';
import LinkGuardScreen from '../screens/LinkGuardScreen';
import MessageGuardScreen from '../screens/MessageGuardScreen';
import DownloadGuardScreen from '../screens/DownloadGuardScreen';
import AppGuardScreen from '../screens/AppGuardScreen';
import WebGuardScreen from '../screens/WebGuardScreen';
import ProtectionSettingsScreen from '../screens/ProtectionSettingsScreen';

export type GuardParam = 'link' | 'message' | 'download' | 'app' | 'web';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const navTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.bg,
    card: colors.card,
    border: colors.border,
    text: colors.text,
    primary: colors.cyan,
  },
};

const TAB_ICONS: Record<string, { on: keyof typeof Ionicons.glyphMap; off: keyof typeof Ionicons.glyphMap }> = {
  Home: { on: 'shield-half', off: 'shield-half-outline' },
  Dashboard: { on: 'grid', off: 'grid-outline' },
  Alerts: { on: 'notifications', off: 'notifications-outline' },
  History: { on: 'time', off: 'time-outline' },
  Settings: { on: 'settings', off: 'settings-outline' },
};

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: 66,
          paddingBottom: 10,
          paddingTop: 8,
        },
        tabBarActiveTintColor: colors.cyan,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarLabelStyle: { fontSize: 10.5, fontWeight: '700', letterSpacing: 0.4 },
        tabBarIcon: ({ color, size, focused }) => {
          const icons = TAB_ICONS[route.name];
          const name = focused ? icons.on : icons.off;
          return <Ionicons name={name} color={color} size={size} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Alerts" component={AlertsScreen} />
      <Tab.Screen name="History" component={HistoryScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: colors.bg },
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen name="Main" component={Tabs} />
        <Stack.Screen name="LinkGuard" component={LinkGuardScreen} />
        <Stack.Screen name="MessageGuard" component={MessageGuardScreen} />
        <Stack.Screen name="DownloadGuard" component={DownloadGuardScreen} />
        <Stack.Screen name="AppGuard" component={AppGuardScreen} />
        <Stack.Screen name="WebGuard" component={WebGuardScreen} />
        <Stack.Screen name="ProtectionSettings" component={ProtectionSettingsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
