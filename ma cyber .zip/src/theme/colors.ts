/** MA CYBER SHIELD - Neon dark theme */
export const colors = {
  bg: '#04070F',
  bgSecondary: '#070C18',
  card: '#0B1220',
  cardLight: '#101A2E',
  border: '#1B2740',
  borderLight: '#24334F',

  cyan: '#00E5FF',
  blue: '#2979FF',
  green: '#00E676',
  yellow: '#FFD600',
  red: '#FF1744',
  orange: '#FF9100',
  purple: '#B388FF',
  pink: '#FF4081',

  white: '#FFFFFF',
  text: '#E8EDF5',
  textSecondary: '#8A94A6',
  textMuted: '#5A6478',
};

export const guardTheme = {
  link: { color: colors.blue, icon: 'link', label: 'Link Guard' },
  message: { color: colors.green, icon: 'chatbubble-ellipses', label: 'Message Guard' },
  download: { color: colors.yellow, icon: 'download', label: 'Download Guard' },
  app: { color: colors.purple, icon: 'apps', label: 'App Guard' },
  web: { color: colors.cyan, icon: 'globe', label: 'Web Guard' },
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radius = {
  sm: 10,
  md: 14,
  lg: 20,
  xl: 28,
};
