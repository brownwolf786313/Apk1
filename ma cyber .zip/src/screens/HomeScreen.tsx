import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import ScreenWrapper from '../components/ScreenWrapper';
import ShieldLogo from '../components/ShieldLogo';
import StatusCard from '../components/StatusCard';
import ChecklistItem from '../components/ChecklistItem';
import FlowDiagram from '../components/FlowDiagram';
import PermissionItem from '../components/PermissionItem';
import { colors, radius } from '../theme/colors';

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <View style={styles.sectionBar} />
        <Text style={styles.sectionTitle}>{title}</Text>
      </View>
      <View style={styles.sectionCard}>{children}</View>
    </View>
  );
}

export default function HomeScreen() {
  return (
    <ScreenWrapper>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Brand header */}
        <View style={styles.brand}>
          <ShieldLogo size={104} />
          <Text style={styles.appName}>MA CYBER SHIELD</Text>
          <Text style={styles.tagline}>24/7 DIGITAL PROTECTION</Text>
          <View style={styles.sloganRow}>
            <Ionicons name="ban" size={12} color={colors.red} />
            <Text style={styles.slogan}> Block Scams </Text>
            <Text style={styles.sloganDot}>•</Text>
            <Text style={styles.slogan}> Stop Phishing </Text>
            <Text style={styles.sloganDot}>•</Text>
            <Text style={styles.slogan}> Stay Safe</Text>
          </View>
        </View>

        {/* Protection status */}
        <StatusCard title="Protection Active" subtitle="Your device is safe" />

        {/* Live monitoring checklist */}
        <Section title="REAL-TIME MONITORING">
          <ChecklistItem icon="link" label="Monitoring links & websites" />
          <ChecklistItem icon="chatbubble-ellipses" label="Scanning messages for scams" />
          <ChecklistItem icon="download" label="Checking downloads for malware" />
          <ChecklistItem icon="apps" label="Protecting your installed apps" last />
        </Section>

        {/* Real-time protection description */}
        <Section title="HOW IT WORKS">
          <Text style={styles.desc}>
            MA CYBER SHIELD runs a persistent 24/7 protection service that never
            sleeps. Every link you tap, message you receive, file you download and
            app you install is scanned in real time by the on-device Threat Engine —
            threats are blocked before they can touch your data.
          </Text>
        </Section>

        {/* 24/7 protection flow */}
        <Section title="24/7 PROTECTION FLOW">
          <FlowDiagram />
        </Section>

        {/* Required permissions */}
        <Section title="REQUIRED PERMISSIONS">
          <PermissionItem icon="stats-chart" label="Usage Access" subtitle="App Guard analyses installed apps" granted />
          <PermissionItem icon="notifications" label="Notification Access" subtitle="Message Guard scans incoming alerts" granted />
          <PermissionItem icon="body" label="Accessibility" subtitle="Link Guard intercepts dangerous URLs" granted />
          <PermissionItem icon="folder-open" label="Storage" subtitle="Download Guard scans saved files" granted />
          <PermissionItem icon="wifi" label="Internet" subtitle="Cloud threat-intelligence updates" granted />
          <PermissionItem icon="lock-closed" label="Device Admin" subtitle="Theft protection (remote lock / wipe)" granted optional />
        </Section>

        {/* Final branding card */}
        <View style={styles.brandCard}>
          <Ionicons name="shield-checkmark" size={34} color={colors.cyan} />
          <Text style={styles.brandCardTitle}>Your Security. Our Mission.</Text>
          <Text style={styles.brandCardSlogan}>BEFORE IT HAPPENS, WE STOP IT.</Text>
        </View>

        <Text style={styles.footer}>MA CYBER SHIELD v1.0.0 • Block Scams • Stop Phishing • Stay Safe</Text>
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 32, gap: 16 },
  brand: { alignItems: 'center', paddingVertical: 18, gap: 6 },
  appName: {
    color: colors.white,
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 4,
    marginTop: 10,
    textShadowColor: colors.cyan,
    textShadowRadius: 18,
    textShadowOffset: { width: 0, height: 0 },
  },
  tagline: { color: colors.cyan, fontSize: 12, fontWeight: '800', letterSpacing: 5 },
  sloganRow: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  slogan: { color: colors.textSecondary, fontSize: 12, fontWeight: '600' },
  sloganDot: { color: colors.cyan, marginHorizontal: 2 },
  section: { gap: 10 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  sectionBar: { width: 4, height: 14, borderRadius: 2, backgroundColor: colors.cyan },
  sectionTitle: { color: colors.textSecondary, fontSize: 11, fontWeight: '900', letterSpacing: 2 },
  sectionCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  desc: { color: colors.textSecondary, fontSize: 13, lineHeight: 20, paddingVertical: 10 },
  brandCard: {
    backgroundColor: colors.card,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: colors.cyan + '55',
    alignItems: 'center',
    paddingVertical: 28,
    paddingHorizontal: 20,
    gap: 10,
    shadowColor: colors.cyan,
    shadowOpacity: 0.25,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 0 },
    elevation: 10,
  },
  brandCardTitle: { color: colors.white, fontSize: 18, fontWeight: '900', letterSpacing: 0.5 },
  brandCardSlogan: { color: colors.cyan, fontSize: 12, fontWeight: '900', letterSpacing: 2.5 },
  footer: { color: colors.textMuted, fontSize: 10.5, textAlign: 'center', letterSpacing: 0.5, marginTop: 4 },
});
