import React from 'react';
import GuardDetail from '../components/GuardDetail';
import { guardTheme } from '../theme/colors';

export default function DownloadGuardScreen() {
  return (
    <GuardDetail
      config={{
        key: 'download',
        title: 'Download Guard',
        subtitle: 'APK & file malware scanning',
        color: guardTheme.download.color,
        icon: 'download',
        alertTitle: 'Malicious File Detected',
        alertMessage:
          'A downloaded APK matched a known trojan signature and was quarantined before installation. Voice warning announced.',
        threatType: 'Malware / Trojan APK',
        source: 'Download interceptor',
        sampleInput: 'free-vpn-mod.apk',
        scanPlaceholder: 'Enter a file name to scan...',
        scanLabel: 'Check any file name for malware indicators and dangerous extensions.',
        actionLabel: 'Report Threat',
      }}
    />
  );
}
