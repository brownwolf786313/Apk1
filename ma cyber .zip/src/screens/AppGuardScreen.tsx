import React from 'react';
import GuardDetail from '../components/GuardDetail';
import { guardTheme } from '../theme/colors';

export default function AppGuardScreen() {
  return (
    <GuardDetail
      config={{
        key: 'app',
        title: 'App Guard',
        subtitle: 'Installed app risk analysis',
        color: guardTheme.app.color,
        icon: 'apps',
        alertTitle: 'Risky App Detected',
        alertMessage:
          '"Turbo Cleaner Pro" was sideloaded and requests SMS reading plus silent-install permissions — classic spyware behaviour. Review and uninstall it.',
        threatType: 'Spyware / Risky Permissions',
        source: 'Usage stats + package analysis',
        sampleInput: 'Turbo Cleaner Pro',
        scanPlaceholder: 'Enter an app name to analyze...',
        scanLabel: 'Analyze any installed app for risky permission combinations.',
        actionLabel: 'Uninstall App',
      }}
    />
  );
}
