import React from 'react';
import GuardDetail from '../components/GuardDetail';
import { guardTheme } from '../theme/colors';

export default function MessageGuardScreen() {
  return (
    <GuardDetail
      config={{
        key: 'message',
        title: 'Message Guard',
        subtitle: 'SMS & notification scanning',
        color: guardTheme.message.color,
        icon: 'chatbubble-ellipses',
        alertTitle: 'Scam Message Detected',
        alertMessage:
          'An SMS promising a lottery prize was blocked. It contained urgency pressure and a suspicious link. Voice warning announced — do not click any links.',
        threatType: 'SMS Scam / Prize Lure',
        source: 'Notification listener',
        sampleInput: 'Congratulations! You won $1000. Click here immediately to claim your prize.',
        scanPlaceholder: 'Paste a message to scan...',
        scanLabel: 'Scan any SMS or notification text for scam patterns.',
        actionLabel: 'Report Threat',
      }}
    />
  );
}
