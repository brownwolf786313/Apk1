import React from 'react';
import GuardDetail from '../components/GuardDetail';
import { guardTheme } from '../theme/colors';

export default function LinkGuardScreen() {
  return (
    <GuardDetail
      config={{
        key: 'link',
        title: 'Link Guard',
        subtitle: 'Real-time URL scanning',
        color: guardTheme.link.color,
        icon: 'link',
        alertTitle: 'Dangerous Link Detected',
        alertMessage:
          'A phishing link was intercepted in your browser. The page impersonates a bank login and was blocked before it could load. Voice warning announced.',
        threatType: 'Phishing / Credential Theft',
        source: 'Browser interception',
        sampleInput: 'http://secure-paypal-login.xyz/verify',
        scanPlaceholder: 'Paste a URL to scan...',
        scanLabel: 'Scan any URL for phishing, typosquatting and hidden destinations.',
        actionLabel: 'Report Threat',
      }}
    />
  );
}
