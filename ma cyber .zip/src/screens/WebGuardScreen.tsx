import React from 'react';
import GuardDetail from '../components/GuardDetail';
import { guardTheme } from '../theme/colors';

export default function WebGuardScreen() {
  return (
    <GuardDetail
      config={{
        key: 'web',
        title: 'Web Guard',
        subtitle: 'Browser protection',
        color: guardTheme.web.color,
        icon: 'globe',
        alertTitle: 'Dangerous Website Blocked',
        alertMessage:
          'A phishing site hosting a banking credential-harvesting kit was blocked before it could load. Voice warning announced.',
        threatType: 'Phishing Website',
        source: 'Browser interception',
        sampleInput: 'http://netflix-billing-update.top/login',
        scanPlaceholder: 'Paste a website URL to scan...',
        scanLabel: 'Scan any website URL for phishing kits and malicious infrastructure.',
        actionLabel: 'Report Threat',
      }}
    />
  );
}
