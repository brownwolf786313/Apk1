import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import ScreenWrapper from '../components/ScreenWrapper';
import ScreenHeader from '../components/ScreenHeader';
import ToggleRow from '../components/ToggleRow';
import { colors, radius, guardTheme } from '../theme/colors';
import { useApp } from '../context/AppContext';

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>{title}</Text>
      {children}
    </View>
  );
}

function Divider() {
  return <View style={styles.divider} />;
}

const SENSITIVITIES = [
  { key: 'low', label: 'Low', desc: 'Only obvious threats' },
  { key: 'medium', label: 'Medium', desc: 'Balanced detection' },
  { key: 'high', label: 'High', desc: 'Maximum protection' },
] as const;

export default function ProtectionSettingsScreen() {
  const navigation = useNavigation<any>();
  const {
    protectionActive,
    setProtectionActive,
    voiceEnabled,
    setVoiceEnabled,
    foregroundService,
    setForegroundService,
    autoBlock,
    setAutoBlock,
    sensitivity,
    setSensitivity,
    guards,
    toggleGuard,
  } = useApp();

  return (
    <ScreenWrapper>
      <ScreenHeader
        title="Protection Settings"
        subtitle="Guards • Voice • Engine"
        color={colors.cyan}
        onBack={() => navigation.goBack()}
      />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <Card title="MASTER CONTROL">
          <ToggleRow
            icon="shield-half"
            label="24/7 Real-Time Protection"
            subtitle="Master switch for all guards"
            value={protectionActive}
            onChange={setProtectionActive}
            accent={colors.green}
          />
          <Divider />
          <ToggleRow
            icon="flash"
            label="Persistent Foreground Service"
            subtitle="Keeps protection alive when app closes (SPECIAL_USE)"
            value={foregroundService}
            onChange={setForegroundService}
            accent={colors.cyan}
            disabled={!protectionActive}
          />
          <Divider />
          <ToggleRow
            icon="hand-left"
            label="Auto-Block Threats"
            subtitle="Block automatically instead of warning only"
            value={autoBlock}
            onChange={setAutoBlock}
            accent={colors.red}
            disabled={!protectionActive}
          />
        </Card>

        <Card title="VOICE ANNOUNCEMENTS">
          <ToggleRow
            icon="volume-high"
            label="Voice Announcements"
            subtitle="Speaks threat warnings aloud (English, TTS)"
            value={voiceEnabled}
            onChange={setVoiceEnabled}
            accent={colors.purple}
          />
          <View style={styles.voiceNote}>
            <Ionicons name="information-circle-outline" size={14} color={colors.textMuted} />
            <Text style={styles.voiceNoteText}>
              Warnings play automatically — even from the background service — and stop
              after the announcement finishes.
            </Text>
          </View>
        </Card>

        <Card title="PROTECTION GUARDS">
          <ToggleRow
            icon="link"
            label="Link Guard"
            subtitle="Real-time URL scanning & phishing detection"
            value={guards.link}
            onChange={() => toggleGuard('link')}
            accent={guardTheme.link.color}
            disabled={!protectionActive}
          />
          <Divider />
          <ToggleRow
            icon="chatbubble-ellipses"
            label="Message Guard"
            subtitle="SMS / notification scam & URL detection"
            value={guards.message}
            onChange={() => toggleGuard('message')}
            accent={guardTheme.message.color}
            disabled={!protectionActive}
          />
          <Divider />
          <ToggleRow
            icon="globe"
            label="Web Guard"
            subtitle="Browser protection against dangerous sites"
            value={guards.web}
            onChange={() => toggleGuard('web')}
            accent={guardTheme.web.color}
            disabled={!protectionActive}
          />
          <Divider />
          <ToggleRow
            icon="download"
            label="Download Guard"
            subtitle="APK / file scanning on download"
            value={guards.download}
            onChange={() => toggleGuard('download')}
            accent={guardTheme.download.color}
            disabled={!protectionActive}
          />
          <Divider />
          <ToggleRow
            icon="apps"
            label="App Guard"
            subtitle="Installed app risk analysis (UsageStats)"
            value={guards.app}
            onChange={() => toggleGuard('app')}
            accent={guardTheme.app.color}
            disabled={!protectionActive}
          />
        </Card>

        <Card title="THREAT ENGINE">
          <Text style={styles.subLabel}>SCAN SENSITIVITY</Text>
          <View style={styles.segmentRow}>
            {SENSITIVITIES.map((s) => {
              const active = sensitivity === s.key;
              return (
                <Pressable
                  key={s.key}
                  onPress={() => setSensitivity(s.key)}
                  style={[
                    styles.segment,
                    active && { backgroundColor: colors.cyan + '22', borderColor: colors.cyan },
                  ]}
                >
                  <Text style={[styles.segmentLabel, active && { color: colors.cyan }]}>{s.label}</Text>
                  <Text style={styles.segmentDesc}>{s.desc}</Text>
                </Pressable>
              );
            })}
          </View>
        </Card>

        <View style={styles.noteCard}>
          <Ionicons name="lock-closed" size={16} color={colors.green} />
          <Text style={styles.noteText}>
            All scanning runs on-device. No personal data ever leaves your phone.
          </Text>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 32, gap: 14 },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: 6,
  },
  cardTitle: {
    color: colors.textSecondary,
    fontSize: 10.5,
    fontWeight: '900',
    letterSpacing: 2,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 4,
  },
  divider: { height: 1, backgroundColor: colors.border + '66', marginHorizontal: 14 },
  voiceNote: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'flex-start',
    marginHorizontal: 16,
    marginVertical: 12,
    backgroundColor: colors.cardLight,
    borderRadius: radius.md,
    padding: 12,
  },
  voiceNoteText: { color: colors.textSecondary, fontSize: 11.5, flex: 1, lineHeight: 16 },
  subLabel: { color: colors.textMuted, fontSize: 10, fontWeight: '900', letterSpacing: 1.5, paddingHorizontal: 16, paddingTop: 10 },
  segmentRow: { flexDirection: 'row', gap: 8, padding: 16 },
  segment: {
    flex: 1,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingVertical: 10,
    paddingHorizontal: 8,
    alignItems: 'center',
    backgroundColor: colors.cardLight,
    gap: 3,
  },
  segmentLabel: { color: colors.white, fontSize: 13, fontWeight: '800' },
  segmentDesc: { color: colors.textMuted, fontSize: 9, textAlign: 'center' },
  noteCard: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
    backgroundColor: colors.green + '0D',
    borderWidth: 1,
    borderColor: colors.green + '33',
    borderRadius: radius.md,
    padding: 14,
  },
  noteText: { color: colors.textSecondary, fontSize: 12, flex: 1 },
});
