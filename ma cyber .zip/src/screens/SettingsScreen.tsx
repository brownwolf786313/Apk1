import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import ScreenWrapper from '../components/ScreenWrapper';
import ShieldLogo from '../components/ShieldLogo';
import { colors, radius } from '../theme/colors';

function Row({
  icon,
  label,
  subtitle,
  onPress,
  color = colors.cyan,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  subtitle?: string;
  onPress?: () => void;
  color?: string;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.row, pressed && { opacity: 0.75 }]}>
      <View style={[styles.rowIcon, { backgroundColor: color + '14', borderColor: color + '44' }]}>
        <Ionicons name={icon} size={17} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowLabel}>{label}</Text>
        {subtitle ? <Text style={styles.rowSub}>{subtitle}</Text> : null}
      </View>
      {onPress ? <Ionicons name="chevron-forward" size={16} color={colors.textMuted} /> : null}
    </Pressable>
  );
}

function Divider() {
  return <View style={styles.divider} />;
}

export default function SettingsScreen() {
  const navigation = useNavigation<any>();

  const openSystem = (url: string) => Linking.openURL(url).catch(() => {});

  return (
    <ScreenWrapper>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Settings</Text>

        {/* App identity */}
        <View style={styles.appCard}>
          <ShieldLogo size={64} />
          <Text style={styles.appName}>MA CYBER SHIELD</Text>
          <Text style={styles.appTag}>24/7 DIGITAL PROTECTION</Text>
          <View style={styles.versionBadge}>
            <Text style={styles.versionText}>VERSION 1.0.0</Text>
          </View>
        </View>

        {/* Protection */}
        <Text style={styles.groupLabel}>PROTECTION</Text>
        <View style={styles.card}>
          <Row
            icon="shield-half"
            label="Protection Settings"
            subtitle="Guards, voice announcements, engine"
            color={colors.cyan}
            onPress={() => navigation.navigate('ProtectionSettings')}
          />
          <Divider />
          <Row
            icon="notifications"
            label="Notification Access"
            subtitle="Required for Message Guard"
            color={colors.green}
            onPress={() => openSystem('android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS')}
          />
          <Divider />
          <Row
            icon="body"
            label="Accessibility"
            subtitle="Required for Link / Web Guard"
            color={colors.blue}
            onPress={() => openSystem('android.settings.ACCESSIBILITY_SETTINGS')}
          />
          <Divider />
          <Row
            icon="stats-chart"
            label="Usage Access"
            subtitle="Required for App Guard"
            color={colors.purple}
            onPress={() => openSystem('android.settings.USAGE_ACCESS_SETTINGS')}
          />
        </View>

        {/* About */}
        <Text style={styles.groupLabel}>ABOUT</Text>
        <View style={styles.card}>
          <Row icon="information-circle" label="App Version" subtitle="1.0.0 (Cloud build)" color={colors.cyan} />
          <Divider />
          <Row icon="cloud" label="Build System" subtitle="GitHub Actions — free cloud APK builds" color={colors.blue} />
          <Divider />
          <Row icon="lock-closed" label="Privacy" subtitle="All scanning runs on-device. Zero data collection." color={colors.green} />
        </View>

        {/* Final branding */}
        <View style={styles.brandCard}>
          <Ionicons name="shield-checkmark" size={30} color={colors.cyan} />
          <Text style={styles.brandTitle}>Your Security. Our Mission.</Text>
          <Text style={styles.brandSlogan}>BEFORE IT HAPPENS, WE STOP IT.</Text>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 32, gap: 14 },
  title: { color: colors.white, fontSize: 26, fontWeight: '900' },
  groupLabel: { color: colors.textSecondary, fontSize: 10.5, fontWeight: '900', letterSpacing: 2, marginTop: 6 },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: 4,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 13 },
  rowIcon: { width: 38, height: 38, borderRadius: 11, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  rowLabel: { color: colors.white, fontSize: 14, fontWeight: '700' },
  rowSub: { color: colors.textSecondary, fontSize: 11.5, marginTop: 2 },
  divider: { height: 1, backgroundColor: colors.border + '66', marginHorizontal: 14 },
  appCard: {
    backgroundColor: colors.card,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: colors.cyan + '44',
    alignItems: 'center',
    paddingVertical: 24,
    gap: 8,
  },
  appName: { color: colors.white, fontSize: 17, fontWeight: '900', letterSpacing: 3, marginTop: 6 },
  appTag: { color: colors.cyan, fontSize: 10.5, fontWeight: '800', letterSpacing: 3 },
  versionBadge: {
    marginTop: 6,
    backgroundColor: colors.cardLight,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 999,
  },
  versionText: { color: colors.textSecondary, fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  brandCard: {
    backgroundColor: colors.card,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: colors.cyan + '55',
    alignItems: 'center',
    paddingVertical: 26,
    paddingHorizontal: 20,
    gap: 10,
    shadowColor: colors.cyan,
    shadowOpacity: 0.2,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  brandTitle: { color: colors.white, fontSize: 17, fontWeight: '900' },
  brandSlogan: { color: colors.cyan, fontSize: 11.5, fontWeight: '900', letterSpacing: 2.5 },
});
