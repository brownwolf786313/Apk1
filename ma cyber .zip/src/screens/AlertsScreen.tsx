import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import ScreenWrapper from '../components/ScreenWrapper';
import ThreatAlertCard from '../components/ThreatAlertCard';
import { colors, radius, guardTheme } from '../theme/colors';
import { useApp, ThreatAlert, GuardType } from '../context/AppContext';

const TYPE_META: Record<string, { icon: keyof typeof Ionicons.glyphMap; color: string }> = {
  link: { icon: 'link', color: guardTheme.link.color },
  message: { icon: 'chatbubble-ellipses', color: guardTheme.message.color },
  download: { icon: 'download', color: guardTheme.download.color },
  app: { icon: 'apps', color: guardTheme.app.color },
  web: { icon: 'globe', color: guardTheme.web.color },
  general: { icon: 'warning', color: colors.red },
};

function timeAgo(ts: number) {
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'Just now';
  if (min < 60) return `${min}m ago`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function AlertsScreen() {
  const { alerts, clearAlerts, simulateThreat } = useApp();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 700);
  }, []);

  return (
    <ScreenWrapper>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Threat Alerts</Text>
          <Text style={styles.subtitle}>Real-time protection notifications</Text>
        </View>
        <Pressable onPress={() => simulateThreat('link')} style={styles.simBtn}>
          <Ionicons name="flash" size={13} color={colors.cyan} />
          <Text style={styles.simText}>Simulate</Text>
        </Pressable>
      </View>

      <FlatList
        data={alerts}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.cyan} colors={[colors.cyan]} />
        }
        ListHeaderComponent={
          alerts.length > 0 ? (
            <View style={styles.listHeader}>
              <Text style={styles.countText}>{alerts.length} active alert{alerts.length !== 1 ? 's' : ''}</Text>
              <Pressable onPress={clearAlerts} style={styles.clearBtn}>
                <Ionicons name="trash-outline" size={13} color={colors.red} />
                <Text style={styles.clearText}>Clear All</Text>
              </Pressable>
            </View>
          ) : null
        }
        renderItem={({ item }) => {
          const meta = TYPE_META[item.type] || TYPE_META.general;
          return (
            <ThreatAlertCard
              icon={meta.icon}
              color={meta.color}
              title={item.title}
              message={item.message}
              time={timeAgo(item.timestamp)}
              blocked={item.blocked}
            />
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <View style={styles.emptyIcon}>
              <Ionicons name="shield-checkmark" size={40} color={colors.green} />
            </View>
            <Text style={styles.emptyTitle}>All Clear</Text>
            <Text style={styles.emptySub}>No active threats. Your device is protected 24/7.</Text>
          </View>
        }
      />
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 14,
  },
  title: { color: colors.white, fontSize: 26, fontWeight: '900' },
  subtitle: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  simBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.cyan + '14',
    borderWidth: 1,
    borderColor: colors.cyan + '55',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
  },
  simText: { color: colors.cyan, fontSize: 12, fontWeight: '800' },
  list: { paddingHorizontal: 16, paddingBottom: 24, gap: 12 },
  listHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 2 },
  countText: { color: colors.textMuted, fontSize: 12, fontWeight: '600' },
  clearBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 6 },
  clearText: { color: colors.red, fontSize: 12, fontWeight: '700' },
  empty: { alignItems: 'center', paddingTop: 80, gap: 10, paddingHorizontal: 32 },
  emptyIcon: {
    width: 84,
    height: 84,
    borderRadius: 42,
    backgroundColor: colors.green + '14',
    borderWidth: 1,
    borderColor: colors.green + '44',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  emptyTitle: { color: colors.white, fontSize: 20, fontWeight: '900' },
  emptySub: { color: colors.textSecondary, fontSize: 13, textAlign: 'center', lineHeight: 19 },
});
