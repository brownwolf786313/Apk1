import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import ScreenWrapper from '../components/ScreenWrapper';
import { colors, radius, guardTheme } from '../theme/colors';
import { useApp, ThreatEvent, GuardType } from '../context/AppContext';

const FILTERS: { key: GuardType | 'all'; label: string; color: string }[] = [
  { key: 'all', label: 'All', color: colors.cyan },
  { key: 'link', label: 'Links', color: guardTheme.link.color },
  { key: 'message', label: 'Messages', color: guardTheme.message.color },
  { key: 'download', label: 'Downloads', color: guardTheme.download.color },
  { key: 'app', label: 'Apps', color: guardTheme.app.color },
  { key: 'web', label: 'Web', color: guardTheme.web.color },
];

function timeAgo(ts: number) {
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'Just now';
  if (min < 60) return `${min}m ago`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

const RISK_COLOR: Record<string, string> = {
  high: colors.red,
  medium: colors.orange,
  low: colors.yellow,
};

export default function HistoryScreen() {
  const { history } = useApp();
  const [filter, setFilter] = useState<GuardType | 'all'>('all');
  const [refreshing, setRefreshing] = useState(false);

  const filtered = useMemo(
    () => (filter === 'all' ? history : history.filter((h) => h.type === filter)),
    [history, filter]
  );

  const blockedCount = history.filter((h) => h.action === 'Blocked').length;

  return (
    <ScreenWrapper>
      <View style={styles.header}>
        <Text style={styles.title}>Threat History</Text>
        <Text style={styles.subtitle}>{history.length} threats stopped • {blockedCount} auto-blocked</Text>
      </View>

      {/* Filter chips */}
      <View style={styles.chips}>
        {FILTERS.map((f) => {
          const active = filter === f.key;
          return (
            <Pressable
              key={f.key}
              onPress={() => setFilter(f.key)}
              style={[
                styles.chip,
                active && { backgroundColor: f.color + '22', borderColor: f.color },
              ]}
            >
              <Text style={[styles.chipText, active && { color: f.color }]}>{f.label}</Text>
            </Pressable>
          );
        })}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              setTimeout(() => setRefreshing(false), 600);
            }}
            tintColor={colors.cyan}
            colors={[colors.cyan]}
          />
        }
        renderItem={({ item }) => {
          const rc = RISK_COLOR[item.risk] || colors.green;
          return (
            <View style={styles.eventCard}>
              <View style={[styles.riskDot, { backgroundColor: rc }]} />
              <View style={{ flex: 1 }}>
                <View style={styles.eventHeader}>
                  <Text style={styles.eventTitle}>{item.title}</Text>
                  <View style={[styles.actionBadge, { borderColor: rc + '66' }]}>
                    <Text style={[styles.actionText, { color: rc }]}>{item.action.toUpperCase()}</Text>
                  </View>
                </View>
                <Text style={styles.eventDetail} numberOfLines={2}>{item.detail}</Text>
                <Text style={styles.eventTime}>{timeAgo(item.timestamp)}</Text>
              </View>
            </View>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="shield-checkmark" size={44} color={colors.green} />
            <Text style={styles.emptyTitle}>No Threats in This Category</Text>
            <Text style={styles.emptySub}>Nothing has been blocked here yet. Your guards are on high alert.</Text>
          </View>
        }
      />
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 12 },
  title: { color: colors.white, fontSize: 26, fontWeight: '900' },
  subtitle: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    paddingHorizontal: 16,
    paddingBottom: 14,
  },
  chip: {
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.card,
    paddingHorizontal: 13,
    paddingVertical: 7,
    borderRadius: 999,
  },
  chipText: { color: colors.textSecondary, fontSize: 12, fontWeight: '700' },
  list: { paddingHorizontal: 16, paddingBottom: 24, gap: 10 },
  eventCard: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 14,
    alignItems: 'flex-start',
  },
  riskDot: { width: 9, height: 9, borderRadius: 5, marginTop: 5 },
  eventHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  eventTitle: { color: colors.white, fontSize: 14, fontWeight: '800', flex: 1 },
  actionBadge: { borderWidth: 1, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 },
  actionText: { fontSize: 9, fontWeight: '900', letterSpacing: 1 },
  eventDetail: { color: colors.textSecondary, fontSize: 12, marginTop: 4, lineHeight: 17 },
  eventTime: { color: colors.textMuted, fontSize: 10.5, marginTop: 6 },
  empty: { alignItems: 'center', paddingTop: 80, gap: 10, paddingHorizontal: 32 },
  emptyTitle: { color: colors.white, fontSize: 18, fontWeight: '900' },
  emptySub: { color: colors.textSecondary, fontSize: 12.5, textAlign: 'center', lineHeight: 18 },
});
