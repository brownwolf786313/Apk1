import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import ScreenWrapper from '../components/ScreenWrapper';
import BarChart from '../components/BarChart';
import FeatureCard from '../components/FeatureCard';
import NeonButton from '../components/NeonButton';
import { colors, radius, guardTheme } from '../theme/colors';
import { useApp, GuardType } from '../context/AppContext';
import { WEEK_THREATS } from '../data/mockData';

const YESTERDAY = WEEK_THREATS[5];
const TODAY = WEEK_THREATS[4];
const DELTA = Math.round(((12 - YESTERDAY) / YESTERDAY) * 100);

export default function DashboardScreen() {
  const navigation = useNavigation<any>();
  const { threatsBlockedToday, simulateThreat, voiceEnabled } = useApp();

  const openGuard = (g: GuardType) => {
    const map: Record<GuardType, string> = {
      link: 'LinkGuard',
      message: 'MessageGuard',
      download: 'DownloadGuard',
      app: 'AppGuard',
      web: 'WebGuard',
    };
    navigation.navigate(map[g]);
  };

  return (
    <ScreenWrapper>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Security Dashboard</Text>

        {/* Top status */}
        <View style={styles.statusCard}>
          <View style={styles.statusRow}>
            <View style={styles.protectedBadge}>
              <Ionicons name="shield-checkmark" size={16} color={colors.green} />
              <Text style={styles.protectedText}>Protected</Text>
            </View>
            <View style={styles.badge247}>
              <Text style={styles.badge247Text}>24/7</Text>
            </View>
          </View>
          <Text style={styles.noThreats}>No threats detected</Text>
          <Text style={styles.noThreatsSub}>All guards are scanning in real time</Text>
        </View>

        {/* Threats blocked today */}
        <View style={styles.statsCard}>
          <View style={styles.statsHeader}>
            <View>
              <Text style={styles.statsLabel}>THREATS BLOCKED TODAY</Text>
              <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10 }}>
                <Text style={styles.statsValue}>{threatsBlockedToday}</Text>
                <View style={styles.deltaBadge}>
                  <Ionicons name="trending-up" size={12} color={colors.green} />
                  <Text style={styles.deltaText}>+8% from yesterday</Text>
                </View>
              </View>
            </View>
            <View style={styles.chartIcon}>
              <Ionicons name="bar-chart" size={18} color={colors.cyan} />
            </View>
          </View>
          <BarChart />
        </View>

        {/* Feature grid 2x2 */}
        <Text style={styles.gridTitle}>PROTECTION GUARDS</Text>
        <View style={styles.grid}>
          <FeatureCard
            title="Link Guard"
            subtitle="Real-time URL scanning & phishing detection"
            icon="link"
            color={guardTheme.link.color}
            onPress={() => openGuard('link')}
          />
          <FeatureCard
            title="Message Guard"
            subtitle="SMS & notification scam detection"
            icon="chatbubble-ellipses"
            color={guardTheme.message.color}
            onPress={() => openGuard('message')}
          />
          <FeatureCard
            title="Download Guard"
            subtitle="APK & file malware scanning"
            icon="download"
            color={guardTheme.download.color}
            onPress={() => openGuard('download')}
          />
          <FeatureCard
            title="App Guard"
            subtitle="Installed app risk analysis"
            icon="apps"
            color={guardTheme.app.color}
            onPress={() => openGuard('app')}
          />
        </View>

        {/* Web Guard wide card */}
        <FeatureCard
          title="Web Guard"
          subtitle="Browser protection — dangerous websites blocked before they load"
          icon="globe"
            color={guardTheme.web.color}
          onPress={() => openGuard('web')}
        />

        {/* Voice warning test */}
        <View style={styles.testCard}>
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={styles.testTitle}>Voice Warning System</Text>
            <Text style={styles.testSub}>
              {voiceEnabled ? 'ON — threats are announced aloud' : 'OFF — enable in Protection Settings'}
            </Text>
          </View>
          <NeonButton
            label="Test Voice"
            icon="volume-high"
            color={colors.purple}
            onPress={() => simulateThreat('link')}
          />
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 32, gap: 16 },
  title: { color: colors.white, fontSize: 26, fontWeight: '900', letterSpacing: 0.5 },
  statusCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.green + '55',
    padding: 18,
    gap: 6,
    shadowColor: colors.green,
    shadowOpacity: 0.15,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  statusRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  protectedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.green + '1A',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: colors.green + '44',
  },
  protectedText: { color: colors.green, fontWeight: '800', fontSize: 13 },
  badge247: {
    backgroundColor: colors.cyan + '1A',
    borderWidth: 1,
    borderColor: colors.cyan + '55',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  badge247Text: { color: colors.cyan, fontWeight: '900', fontSize: 13, letterSpacing: 2 },
  noThreats: { color: colors.white, fontSize: 17, fontWeight: '800', marginTop: 6 },
  noThreatsSub: { color: colors.textSecondary, fontSize: 12 },
  statsCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 18,
    gap: 16,
  },
  statsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  statsLabel: { color: colors.textMuted, fontSize: 10, fontWeight: '900', letterSpacing: 1.5 },
  statsValue: { color: colors.white, fontSize: 40, fontWeight: '900', lineHeight: 44 },
  deltaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.green + '14',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginBottom: 4,
  },
  deltaText: { color: colors.green, fontSize: 11, fontWeight: '700' },
  chartIcon: {
    width: 38,
    height: 38,
    borderRadius: 11,
    backgroundColor: colors.cyan + '14',
    borderWidth: 1,
    borderColor: colors.cyan + '44',
    alignItems: 'center',
    justifyContent: 'center',
  },
  gridTitle: { color: colors.textSecondary, fontSize: 11, fontWeight: '900', letterSpacing: 2, marginTop: 4 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  testCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.purple + '55',
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  testTitle: { color: colors.white, fontSize: 14, fontWeight: '800' },
  testSub: { color: colors.textSecondary, fontSize: 11.5 },
});
