import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ThreatVoiceType, announceThreat } from '../services/VoiceAnnouncer';
import { SEED_ALERTS, SEED_HISTORY } from '../data/mockData';

export type GuardType = 'link' | 'message' | 'download' | 'app' | 'web';

export interface ThreatAlert {
  id: string;
  type: GuardType | 'general';
  title: string;
  message: string;
  timestamp: number;
  blocked: boolean;
  risk: 'high' | 'medium' | 'low';
}

export interface ThreatEvent {
  id: string;
  type: GuardType;
  title: string;
  detail: string;
  timestamp: number;
  action: string;
  risk: string;
}

export interface Guards {
  link: boolean;
  message: boolean;
  web: boolean;
  download: boolean;
  app: boolean;
}

interface AppContextValue {
  protectionActive: boolean;
  setProtectionActive: (v: boolean) => void;
  voiceEnabled: boolean;
  setVoiceEnabled: (v: boolean) => void;
  foregroundService: boolean;
  setForegroundService: (v: boolean) => void;
  autoBlock: boolean;
  setAutoBlock: (v: boolean) => void;
  sensitivity: 'low' | 'medium' | 'high';
  setSensitivity: (v: 'low' | 'medium' | 'high') => void;
  guards: Guards;
  toggleGuard: (key: keyof Guards) => void;
  alerts: ThreatAlert[];
  history: ThreatEvent[];
  threatsBlockedToday: number;
  addAlert: (a: Omit<ThreatAlert, 'id' | 'timestamp'>) => void;
  simulateThreat: (type: GuardType) => void;
  clearAlerts: () => void;
  hydrated: boolean;
}

const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_KEY = '@ma_cyber_shield_state_v1';

let idCounter = 100;
const nextId = () => `t${Date.now()}_${idCounter++}`;

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [protectionActive, setProtectionActive] = useState(true);
  const [voiceEnabled, setVoiceEnabled] = useState(true); // ON by default
  const [foregroundService, setForegroundService] = useState(true);
  const [autoBlock, setAutoBlock] = useState(true);
  const [sensitivity, setSensitivity] = useState<'low' | 'medium' | 'high'>('high');
  const [guards, setGuards] = useState<Guards>({
    link: true,
    message: true,
    web: true,
    download: true,
    app: true,
  });
  const [alerts, setAlerts] = useState<ThreatAlert[]>(SEED_ALERTS);
  const [history, setHistory] = useState<ThreatEvent[]>(SEED_HISTORY);
  const [threatsBlockedToday, setThreatsBlockedToday] = useState(12);
  const voiceRef = useRef(voiceEnabled);
  voiceRef.current = voiceEnabled;

  // Load persisted state once
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const s = JSON.parse(raw);
          if (typeof s.protectionActive === 'boolean') setProtectionActive(s.protectionActive);
          if (typeof s.voiceEnabled === 'boolean') setVoiceEnabled(s.voiceEnabled);
          if (typeof s.foregroundService === 'boolean') setForegroundService(s.foregroundService);
          if (typeof s.autoBlock === 'boolean') setAutoBlock(s.autoBlock);
          if (s.sensitivity) setSensitivity(s.sensitivity);
          if (s.guards) setGuards(s.guards);
          if (Array.isArray(s.alerts) && s.alerts.length) setAlerts(s.alerts);
          if (Array.isArray(s.history) && s.history.length) setHistory(s.history);
          if (typeof s.threatsBlockedToday === 'number') setThreatsBlockedToday(s.threatsBlockedToday);
        }
      } catch (e) {
        // corrupted storage - keep seeds
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  // Persist on change (after hydration)
  useEffect(() => {
    if (!hydrated) return;
    const state = {
      protectionActive,
      voiceEnabled,
      foregroundService,
      autoBlock,
      sensitivity,
      guards,
      alerts: alerts.slice(0, 40),
      history: history.slice(0, 100),
      threatsBlockedToday,
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => {});
  }, [hydrated, protectionActive, voiceEnabled, foregroundService, autoBlock, sensitivity, guards, alerts, history, threatsBlockedToday]);

  const addAlert = useCallback((a: Omit<ThreatAlert, 'id' | 'timestamp'>) => {
    const alert: ThreatAlert = { ...a, id: nextId(), timestamp: Date.now() };
    setAlerts((prev) => [alert, ...prev].slice(0, 40));
    setHistory((prev) => [
      {
        id: nextId(),
        type: a.type === 'general' ? 'link' : a.type,
        title: a.title,
        detail: a.message,
        timestamp: Date.now(),
        action: a.blocked ? 'Blocked' : 'Review',
        risk: a.risk,
      },
      ...prev,
    ].slice(0, 100));
    setThreatsBlockedToday((n) => n + 1);
  }, []);

  const simulateThreat = useCallback((type: GuardType) => {
    const samples: Record<GuardType, Omit<ThreatAlert, 'id' | 'timestamp'>> = {
      link: {
        type: 'link',
        title: 'Dangerous Link Detected',
        message: 'Phishing URL blocked: http://secure-bank-login.xyz/verify?redirect=1',
        blocked: true,
        risk: 'high',
      },
      message: {
        type: 'message',
        title: 'Scam Message Detected',
        message: 'SMS blocked: "You have won a lottery prize of $50,000. Click here to claim immediately."',
        blocked: true,
        risk: 'high',
      },
      download: {
        type: 'download',
        title: 'Malicious File Detected',
        message: 'Download blocked: free-vpn-mod.apk (trojan signature match)',
        blocked: true,
        risk: 'high',
      },
      app: {
        type: 'app',
        title: 'Risky App Detected',
        message: '"Turbo Cleaner Pro" requests SMS + silent-install permissions (sideloaded)',
        blocked: false,
        risk: 'medium',
      },
      web: {
        type: 'web',
        title: 'Dangerous Website Blocked',
        message: 'Phishing kit detected on: http://netflix-billing-update.top/login',
        blocked: true,
        risk: 'high',
      },
    };
    const alert = samples[type];
    addAlert(alert);
    if (voiceRef.current) {
      // Voice announcement fires even from background-triggered threats
      const { announceThreat } = require('../services/VoiceAnnouncer');
      announceThreat(type);
    }
  }, [addAlert]);

  const clearAlerts = useCallback(() => setAlerts([]), []);

  const toggleGuard = useCallback(
    (key: keyof Guards) => setGuards((g) => ({ ...g, [key]: !g[key] })),
    []
  );

  const value = useMemo<AppContextValue>(
    () => ({
      protectionActive,
      setProtectionActive,
      voiceEnabled,
      setVoiceEnabled,
      foregroundService,
      setForegroundService,
      autoBlock,
      setAutoBlock,
      sensitivity,
      setSensitivity,
      guards,
      toggleGuard,
      alerts,
      history,
      threatsBlockedToday,
      addAlert,
      simulateThreat,
      clearAlerts,
      hydrated,
    }),
    [protectionActive, voiceEnabled, foregroundService, autoBlock, sensitivity, guards, alerts, history, threatsBlockedToday, hydrated, toggleGuard, addAlert, simulateThreat, clearAlerts]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
