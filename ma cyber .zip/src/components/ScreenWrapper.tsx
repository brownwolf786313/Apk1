import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme/colors';

/** Gradient background + safe area wrapper used by every screen. */
export default function ScreenWrapper({
  children,
  edges = ['top'],
}: {
  children: React.ReactNode;
  edges?: ('top' | 'bottom')[];
}) {
  return (
    <View style={styles.root}>
      <LinearGradient
        colors={[colors.bg, colors.bgSecondary, '#03050B']}
        style={StyleSheet.absoluteFill}
      />
      <SafeAreaView style={styles.flex} edges={edges}>
        {children}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
});
