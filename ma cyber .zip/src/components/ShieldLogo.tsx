import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { colors } from '../theme/colors';

/** Glowing neon shield logo with the letter "M". */
export default function ShieldLogo({ size = 110 }: { size?: number }) {
  const glow = useSharedValue(0.35);

  useEffect(() => {
    glow.value = withRepeat(
      withTiming(1, { duration: 1800, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );
  }, []);

  const glowStyle = useAnimatedStyle(() => ({
    opacity: 0.25 + glow.value * 0.5,
    transform: [{ scale: 1 + glow.value * 0.07 }],
  }));

  return (
    <View style={{ width: size + 48, height: size + 48, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View
        style={[
          StyleSheet.absoluteFill,
          {
            borderRadius: 999,
            backgroundColor: colors.cyan,
            shadowColor: colors.cyan,
            shadowOpacity: 0.9,
            shadowRadius: 34,
            shadowOffset: { width: 0, height: 0 },
            elevation: 24,
          },
          glowStyle,
        ]}
      />
      <LinearGradient
        colors={[colors.cyan, colors.blue]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name="shield-half" size={size * 0.52} color="#fff" />
        <View style={{ position: 'absolute', top: size * 0.3, alignItems: 'center' }}>
          <Text style={{ color: '#fff', fontWeight: '900', fontSize: size * 0.26, letterSpacing: 1 }}>M</Text>
        </View>
      </LinearGradient>
    </View>
  );
}
