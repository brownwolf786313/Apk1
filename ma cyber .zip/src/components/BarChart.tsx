import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  Easing,
} from 'react-native-reanimated';
import { colors } from '../theme/colors';

const DATA = [
  { label: 'M', value: 4 },
  { label: 'T', value: 7 },
  { label: 'W', value: 3 },
  { label: 'T', value: 9 },
  { label: 'F', value: 6 },
  { label: 'S', value: 12 },
  { label: 'S', value: 8 },
];

const MAX = 12;

/** 7-day threats-blocked bar chart with grow animation. */
export default function BarChart() {
  const heights = DATA.map(() => useSharedValue(0));

  useEffect(() => {
    heights.forEach((h, i) => {
      h.value = withDelay(i * 90, withTiming((DATA[i].value / MAX) * 100, {
        duration: 700,
        easing: Easing.out(Easing.cubic),
      }));
    });
  }, []);

  return (
    <View style={styles.wrap}>
      {DATA.map((d, i) => (
        <Bar key={i} label={d.label} value={d.value} progress={heights[i]} highlight={d.value === MAX} />
      ))}
    </View>
  );
}

function Bar({ label, value, progress, highlight }: any) {
  const style = useAnimatedStyle(() => ({ height: `${Math.max(progress.value, 6)}%` }));
  return (
    <View style={styles.col}>
      <Text style={[styles.value, highlight && { color: colors.cyan }]}>{value}</Text>
      <View style={styles.track}>
        <Animated.View
          style={[
            styles.bar,
            highlight
              ? { backgroundColor: colors.cyan, shadowColor: colors.cyan, shadowOpacity: 0.8, shadowRadius: 8, shadowOffset: { width: 0, height: 0 } }
              : { backgroundColor: colors.blue + '88' },
            style,
          ]}
        />
      </View>
      <Text style={[styles.label, highlight && { color: colors.cyan }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', height: 120, paddingHorizontal: 4 },
  col: { alignItems: 'center', flex: 1 },
  track: { height: 78, width: 16, borderRadius: 8, backgroundColor: colors.cardLight, justifyContent: 'flex-end', overflow: 'hidden' },
  bar: { width: '100%', borderRadius: 8 },
  value: { color: colors.textSecondary, fontSize: 10, fontWeight: '700', marginBottom: 5 },
  label: { color: colors.textMuted, fontSize: 10, marginTop: 6, fontWeight: '600' },
});
