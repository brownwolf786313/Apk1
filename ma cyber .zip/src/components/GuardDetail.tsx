import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import ScreenWrapper from './ScreenWrapper';
import ScreenHeader from './ScreenHeader';
import NeonButton from './NeonButton';
import { colors, radius } from '../theme/colors';
import { useApp } from '../context/AppContext';
import { announceThreat } from '../services/VoiceAnnouncer';
import {
  scanUrl,
  scanMessage,
  scanFile,
  analyzeApp,
  RISK_COLORS,
  RISK_LABELS,
  ScanResult,
} from '../services/ThreatEngine';

export type GuardKey = 'link' | 'message' | 'download' | 'app' | 'web';

interface GuardConfig {
  key: GuardKey;
  title: string;
  subtitle: string;
  color: string;
  icon: keyof typeof Ionicons.glyphMap;
  alertTitle: string;
  alertMessage: string;
  threatType: string;
  source: string;
  sampleInput: string;
  scanPlaceholder: string;
  scanLabel: string;
  actionLabel: string;
}

function DetailRow({ label, value, color = colors.text }: { label: string; value: string; color?: string }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={[styles.detailValue, { color }]} numberOfLines={2}>{value}</Text>
    </View>
  );
}

export default function GuardDetail({ config }: { config: GuardConfig }) {
  const navigation = useNavigation<any>();
  const { voiceEnabled, addAlert } = useApp();
  const [input, setInput] = useState('');
  const [result, setResult] = useState<ScanResult | null>(null);
  const [reported, setReported] = useState(false);
  const pulse = useSharedValue(0.4);

  useEffect(() => {
    pulse.value = withRepeat(withTiming(1, { duration: 900, easing: Easing.inOut(Easing.ease) }), -1, true);
  }, []);

  // Voice announcement fires automatically when a threat screen opens
  useEffect(() => {
    if (voiceEnabled) {
      const t = setTimeout(() => announceThreat(config.key), 400);
      return () => clearTimeout(t);
    }
  }, []);

  const pulseStyle = useAnimatedStyle(() => ({
    opacity: 0.35 + pulse.value * 0.55,
    transform: [{ scale: 1 + pulse.value * 0.1 }],
  }));

  const runScan = () => {
    const text = input.trim();
    if (!text) return;
    let r: ScanResult;
    switch (config.key) {
      case 'link':
      case 'web':
        r = scanUrl(text);
        break;
      case 'message':
        r = scanMessage(text);
        break;
      case 'download':
        r = scanFile(text);
        break;
      case 'app':
        r = analyzeApp({
          name: text,
          packageName: text.toLowerCase().replace(/\s+/g, '') + '.app',
          permissions: ['READ_SMS', 'CAMERA', 'ACCESS_FINE_LOCATION', 'REQUEST_INSTALL_PACKAGES'],
          source: 'sideload',
        });
        break;
    }
    setResult(r);
  };

  const riskColor = result ? { high: colors.red, medium: colors.orange, low: colors.yellow, safe: colors.green }[result.risk] : colors.green;

  const reportThreat = () => {
    addAlert({
      type: config.key,
      title: config.alertTitle,
      message: config.alertMessage,
      blocked: true,
      risk: 'high',
    });
    setReported(true);
  };

  return (
    <ScreenWrapper>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScreenHeader
          title={config.title}
          subtitle={config.subtitle}
          color={config.color}
          onBack={() => navigation.goBack()}
        />
        <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
          {/* Threat alert card */}
          <View style={[styles.alertCard, { borderColor: config.color + '55' }]}>
            <View style={styles.alertHeader}>
              <View>
                <Animated.View style={[styles.alertGlow, pulseStyle]} />
                <View style={[styles.alertIconWrap, { backgroundColor: colors.red + '1A', borderColor: colors.red + '55' }]}>
                  <Ionicons name="warning" size={26} color={colors.red} />
                </View>
              </View>
              <View style={styles.blockedBadge}>
                <Ionicons name="ban" size={12} color={colors.red} />
                <Text style={styles.blockedText}>BLOCKED</Text>
              </View>
            </View>
            <Text style={styles.alertTitle}>{config.alertTitle}</Text>
            <Text style={styles.alertMessage}>{config.alertMessage}</Text>
            <View style={styles.alertMeta}>
              <Ionicons name="time-outline" size={12} color={colors.textMuted} />
              <Text style={styles.alertMetaText}>Detected just now • Voice warning announced</Text>
            </View>
          </View>

          {/* Threat analysis */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>THREAT ANALYSIS</Text>
            <DetailRow label="Risk Level" value="HIGH" color={colors.red} />
            <DetailRow label="Threat Type" value={config.threatType} />
            <DetailRow label="Source" value={config.source} />
            <DetailRow label="Action Taken" value="Threat blocked automatically" color={colors.green} />
            <DetailRow label="Engine" value="On-device Threat Engine v2.4" />
          </View>

          {/* Live scanner demo */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>LIVE SCANNER</Text>
            <Text style={styles.cardSub}>{config.scanLabel}</Text>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                placeholder={config.scanPlaceholder}
                placeholderTextColor={colors.textMuted}
                value={input}
                onChangeText={setInput}
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="search"
                onSubmitEditing={runScan}
              />
              <Pressable onPress={runScan} style={[styles.scanBtn, { backgroundColor: config.color }]}>
                <Ionicons name="scan" size={18} color="#04070F" />
              </Pressable>
            </View>
            {result && (
              <View style={[styles.resultBox, { borderColor: riskColor + '66' }]}>
                <View style={styles.resultHeader}>
                  <Ionicons
                    name={result.risk === 'safe' ? 'shield-checkmark' : 'alert-circle'}
                    size={18}
                    color={riskColor}
                  />
                  <Text style={[styles.resultRisk, { color: riskColor }]}>{RISK_LABELS[result.risk]}</Text>
                  <Text style={styles.resultScore}>Score {result.score}/100</Text>
                </View>
                {result.reasons.length > 0 ? (
                  result.reasons.map((r, i) => (
                    <View key={i} style={styles.reasonRow}>
                      <Ionicons name="chevron-forward" size={12} color={riskColor} />
                      <Text style={styles.reasonText}>{r}</Text>
                    </View>
                  ))
                ) : (
                  <Text style={styles.safeText}>No threats found — this looks safe.</Text>
                )}
              </View>
            )}
          </View>

          {/* Actions */}
          <View style={styles.actionsRow}>
            <View style={{ flex: 1 }}>
              <NeonButton
                label={reported ? 'Reported ✓' : 'Report Threat'}
                icon={reported ? 'checkmark' : 'flag'}
                color={reported ? colors.green : colors.orange}
                onPress={reportThreat}
                disabled={reported}
              />
            </View>
            <View style={{ flex: 1 }}>
              <NeonButton
                label="Protection Settings"
                icon="options"
                variant="outline"
                color={config.color}
                onPress={() => navigation.navigate('ProtectionSettings')}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 32, gap: 14 },
  alertCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: 18,
    gap: 10,
  },
  alertHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  alertGlow: {
    position: 'absolute',
    top: -8,
    left: -8,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.red,
  },
  alertIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  blockedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.red + '1A',
    borderWidth: 1,
    borderColor: colors.red + '55',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  blockedText: { color: colors.red, fontSize: 10, fontWeight: '900', letterSpacing: 1.5 },
  alertTitle: { color: colors.white, fontSize: 20, fontWeight: '900', letterSpacing: 0.3 },
  alertMessage: { color: colors.textSecondary, fontSize: 13, lineHeight: 19 },
  alertMeta: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 2 },
  alertMetaText: { color: colors.textMuted, fontSize: 11 },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 16,
    gap: 4,
  },
  cardTitle: { color: colors.textSecondary, fontSize: 10.5, fontWeight: '900', letterSpacing: 2, marginBottom: 8 },
  cardSub: { color: colors.textSecondary, fontSize: 12, marginBottom: 8 },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: colors.border + '66' },
  detailLabel: { color: colors.textMuted, fontSize: 12.5 },
  detailValue: { color: colors.white, fontSize: 12.5, fontWeight: '700', maxWidth: '62%', textAlign: 'right' },
  inputRow: { flexDirection: 'row', gap: 10 },
  input: {
    flex: 1,
    backgroundColor: colors.cardLight,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: colors.white,
    fontSize: 13,
  },
  scanBtn: { width: 46, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  resultBox: {
    marginTop: 12,
    backgroundColor: colors.cardLight,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: 12,
    gap: 8,
  },
  resultHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  resultRisk: { fontSize: 13, fontWeight: '900', letterSpacing: 1, flex: 1 },
  resultScore: { color: colors.textMuted, fontSize: 11, fontWeight: '700' },
  reasonRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6 },
  reasonText: { color: colors.textSecondary, fontSize: 12, flex: 1, lineHeight: 17 },
  safeText: { color: colors.green, fontSize: 12.5 },
  actionsRow: { flexDirection: 'row', gap: 12 },
});
