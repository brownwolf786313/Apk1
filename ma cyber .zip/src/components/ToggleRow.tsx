import React from 'react';
import { View, Text, StyleSheet, Switch, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

export default function ToggleRow({
  icon,
  label,
  subtitle,
  value,
  onChange,
  accent = colors.cyan,
  disabled = false,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  subtitle?: string;
  value: boolean;
  onChange: (v: boolean) => void;
  accent?: string;
  disabled?: boolean;
}) {
  return (
    <Pressable onPress={() => !disabled && onChange(!value)} style={[styles.row, disabled && { opacity: 0.5 }]}>
      <View style={[styles.iconWrap, { backgroundColor: accent + '14', borderColor: accent + '44' }]}>
        <Ionicons name={icon} size={18} color={accent} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.label}>{label}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        disabled={disabled}
        trackColor={{ false: colors.border, true: accent + '88' }}
        thumbColor={value ? accent : colors.textMuted}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 13,
    paddingHorizontal: 14,
  },
  iconWrap: {
    width: 38,
    height: 38,
    borderRadius: 11,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: { color: colors.white, fontSize: 14, fontWeight: '700' },
  subtitle: { color: colors.textSecondary, fontSize: 11.5, marginTop: 2 },
});
