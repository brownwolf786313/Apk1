import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

export default function ChecklistItem({
  icon,
  label,
  done = true,
  accent = colors.green,
  last = false,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  done?: boolean;
  accent?: string;
  last?: boolean;
}) {
  return (
    <View style={styles.row}>
      <View style={[styles.iconWrap, { borderColor: accent + '55', backgroundColor: accent + '14' }]}>
        <Ionicons name={icon} size={17} color={accent} />
      </View>
      <Text style={styles.label}>{label}</Text>
      <Ionicons
        name={done ? 'checkmark-circle' : 'ellipse-outline'}
        size={20}
        color={done ? colors.green : colors.textMuted}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11 },
  iconWrap: {
    width: 34,
    height: 34,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: { color: colors.text, fontSize: 14, fontWeight: '600', flex: 1 },
});
