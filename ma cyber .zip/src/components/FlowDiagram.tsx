import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

const STEPS = [
  { icon: 'scan' as const, label: 'Monitor', color: colors.cyan },
  { icon: 'pulse' as const, label: 'Analyze', color: colors.blue },
  { icon: 'shield' as const, label: 'Block / Warn', color: colors.orange },
  { icon: 'checkmark-done' as const, label: 'Keep You Safe', color: colors.green },
];

/** 24/7 Protection flow: Monitor -> Analyze -> Block/Warn -> Keep You Safe */
export default function FlowDiagram() {
  return (
    <View style={styles.wrap}>
      {STEPS.map((s, i) => (
        <React.Fragment key={s.label}>
          <View style={styles.step}>
            <View style={[styles.iconWrap, { borderColor: s.color + '66', backgroundColor: s.color + '14' }]}>
              <Ionicons name={s.icon} size={20} color={s.color} />
            </View>
            <Text style={styles.stepLabel}>{s.label}</Text>
          </View>
          {i < STEPS.length - 1 && (
            <View style={styles.arrowWrap}>
              <View style={styles.arrowLine} />
              <Ionicons name="chevron-forward" size={14} color={colors.cyan} />
            </View>
          )}
        </React.Fragment>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center' },
  step: { alignItems: 'center', flex: 1, gap: 7 },
  iconWrap: { width: 48, height: 48, borderRadius: 14, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  stepLabel: { color: colors.text, fontSize: 10.5, fontWeight: '700', textAlign: 'center' },
  arrowWrap: { flexDirection: 'row', alignItems: 'center', paddingBottom: 18, gap: 2 },
  arrowLine: { width: 14, height: 1.5, backgroundColor: colors.cyan + '66' },
});
