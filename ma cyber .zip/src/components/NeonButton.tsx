import React from 'react';
import { Text, StyleSheet, Pressable, ViewStyle, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius } from '../theme/colors';

export default function NeonButton({
  label,
  icon,
  onPress,
  color = colors.cyan,
  variant = 'solid',
  disabled = false,
  loading = false,
  style,
}: {
  label: string;
  icon?: keyof typeof Ionicons.glyphMap;
  onPress?: () => void;
  color?: string;
  variant?: 'solid' | 'outline' | 'danger';
  disabled?: boolean;
  loading?: boolean;
  style?: object;
}) {
  const isDanger = variant === 'danger';
  const accent = isDanger ? colors.red : color;

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.base,
        variant === 'outline' && { backgroundColor: 'transparent', borderWidth: 1, borderColor: accent + '88' },
        pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
        (disabled || loading) && { opacity: 0.5 },
        style as ViewStyle,
      ]}
    >
      {variant !== 'outline' ? (
        <LinearGradient
          colors={isDanger ? ['#FF1744', '#D50000'] : [accent, accent + '99']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      ) : null}
      {loading ? (
        <ActivityIndicator color="#fff" size="small" />
      ) : (
        <>
          {icon ? <Ionicons name={icon} size={17} color="#fff" style={{ marginRight: 8 }} /> : null}
          <Text style={styles.label}>{label}</Text>
        </>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: radius.md,
    overflow: 'hidden',
  },
  label: { color: '#fff', fontWeight: '800', fontSize: 14, letterSpacing: 0.4 },
});
