import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

/** One row in the Required Permissions checklist. */
export default function PermissionItem({
  icon,
  label,
  subtitle,
  granted,
  optional = false,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  subtitle: string;
  granted: boolean;
  optional?: boolean;
}) {
  return (
    <View style={styles.row}>
      <View style={[styles.iconWrap, { borderColor: granted ? colors.green + '55' : colors.border, backgroundColor: granted ? colors.green + '12' : colors.cardLight }]}>
        <Ionicons name={icon} size={17} color={granted ? colors.green : colors.textMuted} />
      </View>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={styles.label}>{label}</Text>
          {optional && (
            <View style={styles.optBadge}>
              <Text style={styles.optText}>OPTIONAL</Text>
            </View>
          )}
        </View>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>
      <Ionicons
        name={granted ? 'checkmark-circle' : 'ellipse-outline'}
        size={20}
        color={granted ? colors.green : colors.textMuted}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11 },
  iconWrap: { width: 36, height: 36, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  label: { color: colors.white, fontSize: 13.5, fontWeight: '700' },
  subtitle: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  optBadge: { backgroundColor: colors.yellow + '1A', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 5 },
  optText: { color: colors.yellow, fontSize: 8, fontWeight: '900', letterSpacing: 1 },
});
