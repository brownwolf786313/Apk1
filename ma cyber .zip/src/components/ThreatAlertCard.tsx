import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius } from '../theme/colors';

/** Notification-style threat alert card. */
export default function ThreatAlertCard({
  icon,
  color,
  title,
  message,
  time,
  blocked = true,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  title: string;
  message: string;
  time: string;
  blocked?: boolean;
}) {
  return (
    <View style={[styles.card, { borderLeftColor: color }]}>
      <View style={[styles.iconWrap, { backgroundColor: color + '1A' }]}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <View style={styles.titleRow}>
          <Text style={styles.title} numberOfLines={1}>{title}</Text>
          {blocked && (
            <View style={styles.blockedBadge}>
              <Ionicons name="ban" size={10} color={colors.red} />
              <Text style={styles.blockedText}>BLOCKED</Text>
            </View>
          )}
        </View>
        <Text style={styles.message} numberOfLines={2}>{message}</Text>
        <Text style={styles.time}>{time}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    borderLeftWidth: 4,
    padding: 14,
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  title: { color: colors.white, fontSize: 14, fontWeight: '800', flex: 1 },
  blockedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255, 23, 68, 0.12)',
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 6,
  },
  blockedText: { color: colors.red, fontSize: 9, fontWeight: '900', letterSpacing: 1 },
  message: { color: colors.textSecondary, fontSize: 12, marginTop: 4, lineHeight: 17 },
  time: { color: colors.textMuted, fontSize: 10.5, marginTop: 6 },
});
