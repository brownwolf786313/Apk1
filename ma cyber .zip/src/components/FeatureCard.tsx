import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius } from '../theme/colors';

export default function FeatureCard({
  title,
  subtitle,
  icon,
  color,
  onPress,
  wide = false,
}: {
  title: string;
  subtitle: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  onPress?: () => void;
  wide?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        wide && { flex: 1 },
        pressed && { transform: [{ scale: 0.97 }], opacity: 0.9 },
        { borderColor: color + '44' },
      ]}
    >
      <View style={[styles.iconWrap, { backgroundColor: color + '1A', borderColor: color + '55' }]}>
        <Ionicons name={icon} size={26} color={color} />
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
      <View style={[styles.tag, { backgroundColor: color + '1A' }]}>
        <Text style={[styles.tagText, { color }]}>ACTIVE</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: 16,
    flex: 1,
    minHeight: 148,
  },
  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  title: { color: colors.white, fontSize: 15, fontWeight: '800', letterSpacing: 0.3 },
  subtitle: { color: colors.textSecondary, fontSize: 11.5, marginTop: 4, lineHeight: 16 },
  tag: {
    alignSelf: 'flex-start',
    marginTop: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  tagText: { fontSize: 9, fontWeight: '900', letterSpacing: 1.2 },
});
