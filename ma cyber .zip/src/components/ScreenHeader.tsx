import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

/** Custom header with back button for stack screens. */
export default function ScreenHeader({
  title,
  subtitle,
  color = colors.cyan,
  onBack,
  right,
}: {
  title: string;
  subtitle?: string;
  color?: string;
  onBack?: () => void;
  right?: React.ReactNode;
}) {
  return (
    <View style={styles.wrap}>
      <View style={styles.row}>
        {onBack ? (
          <View style={[styles.backBtn, { borderColor: color + '55' }]}>
            <Ionicons name="arrow-back" size={20} color={color} onPress={onBack} />
          </View>
        ) : null}
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{title}</Text>
          {subtitle ? <Text style={[styles.subtitle, { color }]}>{subtitle}</Text> : null}
        </View>
        {right}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.card,
  },
  title: { color: colors.white, fontSize: 20, fontWeight: '900', letterSpacing: 0.3 },
  subtitle: { fontSize: 11, fontWeight: '700', letterSpacing: 1.2, marginTop: 2, textTransform: 'uppercase' },
});
