import { ThreatAlert, ThreatEvent } from '../context/AppContext';

const now = Date.now();
const MIN = 60 * 1000;
const HOUR = 60 * MIN;

export const SEED_ALERTS: ThreatAlert[] = [
  {
    id: 'a1',
    type: 'link',
    title: 'Dangerous Link Detected',
    message: 'Phishing URL blocked in browser: http://secure-paypal-login.xyz/verify',
    timestamp: now - 12 * MIN,
    blocked: true,
    risk: 'high',
  },
  {
    id: 'a2',
    type: 'message',
    title: 'Scam Message Detected',
    message: 'SMS blocked: "Congratulations! You won a $1000 prize. Click here to claim."',
    timestamp: now - 47 * MIN,
    blocked: true,
    risk: 'high',
  },
  {
    id: 'a3',
    type: 'download',
    title: 'Malicious File Detected',
    message: 'Download blocked: free-vpn-mod.apk (trojan signature match)',
    timestamp: now - 3 * HOUR,
    blocked: true,
    risk: 'high',
  },
  {
    id: 'a4',
    type: 'web',
    title: 'Dangerous Website Blocked',
    message: 'Phishing kit detected on: http://netflix-billing-update.top',
    timestamp: now - 5 * HOUR,
    blocked: true,
    risk: 'high',
  },
  {
    id: 'a5',
    type: 'app',
    title: 'Risky App Found',
    message: '"Turbo Cleaner Pro" requests SMS + install permissions (sideloaded)',
    timestamp: now - 8 * HOUR,
    blocked: false,
    risk: 'medium',
  },
];

export const SEED_HISTORY: ThreatEvent[] = [
  { id: 'h1', type: 'link', title: 'Phishing link blocked', detail: 'http://secure-paypal-login.xyz/verify', timestamp: now - 12 * MIN, action: 'Blocked', risk: 'high' },
  { id: 'h2', type: 'message', title: 'Scam SMS blocked', detail: 'Lottery winner lure from +1 (555) 013-4477', timestamp: now - 47 * MIN, action: 'Blocked', risk: 'high' },
  { id: 'h3', type: 'download', title: 'Malicious APK blocked', detail: 'free-vpn-mod.apk - trojan signature', timestamp: now - 3 * HOUR, action: 'Blocked', risk: 'high' },
  { id: 'h4', type: 'web', title: 'Phishing site blocked', detail: 'netflix-billing-update.top', timestamp: now - 5 * HOUR, action: 'Blocked', risk: 'high' },
  { id: 'h5', type: 'app', title: 'Risky app flagged', detail: 'Turbo Cleaner Pro - sideloaded', timestamp: now - 8 * HOUR, action: 'Review', risk: 'medium' },
  { id: 'h6', type: 'link', title: 'Shortened URL blocked', detail: 'bit.ly/3xK... - hidden destination', timestamp: now - 26 * HOUR, action: 'Blocked', risk: 'medium' },
  { id: 'h7', type: 'message', title: 'Bank impersonation SMS', detail: '"Account suspended" lure from +1 (555) 019-2210', timestamp: now - 30 * HOUR, action: 'Blocked', risk: 'high' },
  { id: 'h8', type: 'download', title: 'Cracked game APK blocked', detail: 'minecraft-mod-premium.apk', timestamp: now - 2 * 24 * HOUR, action: 'Blocked', risk: 'high' },
  { id: 'h9', type: 'web', title: 'Crypto drainer site blocked', detail: 'free-airdrop-claim.xyz', timestamp: now - 3 * 24 * HOUR, action: 'Blocked', risk: 'high' },
  { id: 'h10', type: 'app', title: 'Spyware signature matched', detail: 'QuickCleaner Pro - sideloaded', timestamp: now - 4 * 24 * HOUR, action: 'Uninstall', risk: 'high' },
];

export const WEEK_THREATS = [4, 7, 3, 9, 6, 12, 8];
