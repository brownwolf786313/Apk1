/**
 * MA CYBER SHIELD - Threat Engine
 * Real heuristic scanning for URLs, messages, files and apps.
 * Pure TypeScript - runs on-device, no network calls.
 */

export type RiskLevel = 'high' | 'medium' | 'low' | 'safe';

export interface ScanResult {
  risk: RiskLevel;
  score: number; // 0-100
  reasons: string[];
}

const SHORTENERS = ['bit.ly', 'tinyurl', 'goo.gl', 't.co', 'ow.ly', 'is.gd', 'shorte.st', 'rb.gy'];
const SUSPICIOUS_TLDS = ['.xyz', '.top', '.gq', '.ml', '.cf', '.tk', '.cc', '.biz'];
const SENSITIVE_WORDS = ['login', 'verify', 'account', 'secure', 'update', 'confirm', 'password', 'bank', 'paypal', 'win', 'prize', 'free', 'urgent', 'suspended', 'limited', 'offer', 'invoice', 'refund', 'otp', 'ssn'];
const BRANDS = ['paypal', 'amazon', 'google', 'apple', 'microsoft', 'netflix', 'bank', 'whatsapp', 'instagram', 'facebook', 'chase', 'wells'];

function riskFromScore(score: number): RiskLevel {
  if (score >= 60) return 'high';
  if (score >= 35) return 'medium';
  if (score >= 15) return 'low';
  return 'safe';
}

/** Link Guard / Web Guard - URL phishing heuristics. */
export function scanUrl(input: string): ScanResult {
  let url = input.trim().toLowerCase();
  if (!url) return { risk: 'safe', score: 0, reasons: [] };
  if (!url.startsWith('http')) url = 'https://' + url;

  let score = 0;
  const reasons: string[] = [];

  if (/^https?:\/\/\d{1,3}(\.\d{1,3}){3}/.test(url) || /\/\d{1,3}(\.\d{1,3}){2,}/.test(url)) {
    score += 35;
    reasons.push('URL uses a raw IP address instead of a domain name');
  }
  if (SHORTENERS.some((s) => url.includes(s))) {
    score += 25;
    reasons.push('Link-shortening service hides the real destination');
  }
  if (url.startsWith('http://')) {
    score += 15;
    reasons.push('Unencrypted HTTP connection (no HTTPS)');
  }
  for (const w of SENSITIVE_WORDS) {
    if (url.includes(w)) {
      score += 10;
      reasons.push(`Domain contains sensitive keyword "${w}"`);
      break;
    }
  }
  for (const b of BRANDS) {
    if (url.includes(b) && !url.includes(b + '.com') && !url.includes(b + '.net')) {
      score += 20;
      reasons.push(`Possible typosquatting of the "${b}" brand`);
      break;
    }
  }
  for (const t of SUSPICIOUS_TLDS) {
    if (url.includes(t)) {
      score += 10;
      reasons.push(`Unusual top-level domain (${t})`);
      break;
    }
  }
  if (url.includes('@')) {
    score += 20;
    reasons.push('"@" symbol detected - classic credential-harvesting pattern');
  }
  if (/:\d{2,5}\//.test(url)) {
    score += 10;
    reasons.push('Non-standard port specified in URL');
  }
  if (url.includes('redirect') || url.includes('url=') || url.includes('next=') || url.includes('continue=')) {
    score += 15;
    reasons.push('Open-redirect parameter detected');
  }
  if (url.includes('login') && url.includes('verify')) {
    score += 10;
    reasons.push('Combined login + verification lure pattern');
  }

  score = Math.min(100, score);
  return { risk: riskFromScore(score), score, reasons };
}

const SCAM_KEYWORDS = [
  'lottery', 'winner', 'prize', 'claim your', 'verify your account',
  'account suspended', 'click here', 'urgent action', 'bank alert',
  'otp', 'password', 'refund', 'package delivery', 'you have won',
  'free gift', 'limited time', 'immediately', 'congratulations',
  'ssn', 'social security', 'debit card', 'blocked account',
];

/** Message Guard - SMS / notification scam heuristics. */
export function scanMessage(text: string): ScanResult {
  const t = text.toLowerCase();
  let score = 0;
  const reasons: string[] = [];
  const hits: string[] = [];

  for (const k of SCAM_KEYWORDS) {
    if (t.includes(k)) {
      hits.push(k);
      score += 18;
    }
  }
  if (hits.length > 0) {
    reasons.push(`Scam keywords detected: "${hits.slice(0, 3).join('", "')}"`);
  }
  const urls = t.match(/(https?:\/\/|www\.)\S+/g) || [];
  if (urls.length > 0) {
    score += 20;
    reasons.push(`Message contains ${urls.length} link(s) - never click unknown links`);
  }
  if (/\b\d{4,}\b/.test(text) && t.includes('otp')) {
    score += 15;
    reasons.push('Requests a one-time password (OTP) - banks never ask by SMS');
  }
  if (/act now|immediately|expires|last chance/i.test(text)) {
    score += 10;
    reasons.push('Urgency pressure tactics detected');
  }
  if (/\$\d|[0-9]+\s*(usd|dollars|rs\.|rupees)/i.test(text)) {
    score += 10;
    reasons.push('Promises money or a cash reward');
  }

  score = Math.min(100, score);
  return { risk: riskFromScore(score), score, reasons };
}

const MALICIOUS_EXTENSIONS = ['.apk', '.exe', '.bat', '.scr', '.js', '.vbs', '.jar', '.msi', '.com', '.pif'];
const MALICIOUS_NAMES = ['mod', 'crack', 'patch', 'keygen', 'free-vpn', 'hack', 'premium', 'cracked'];

/** Download Guard - file name heuristics. */
export function scanFile(fileName: string): ScanResult {
  const name = fileName.toLowerCase();
  let score = 0;
  const reasons: string[] = [];

  for (const ext of MALICIOUS_EXTENSIONS) {
    if (name.endsWith(ext)) {
      score += 30;
      reasons.push(`Executable file type (${ext}) - Android blocks unknown APK installs`);
      break;
    }
  }
  const dotCount = (name.match(/\./g) || []).length;
  if (dotCount >= 2) {
    score += 20;
    reasons.push('Double file extension - classic malware disguise (e.g. file.pdf.apk)');
  }
  for (const n of MALICIOUS_NAMES) {
    if (name.includes(n)) {
      score += 25;
      reasons.push(`Piracy/crack indicator in file name ("${n}")`);
      break;
    }
  }
  if (name.includes('vpn') && name.includes('free')) {
    score += 15;
    reasons.push('Unofficial free VPN - often bundles spyware');
  }

  score = Math.min(100, score);
  return { risk: riskFromScore(score), score, reasons };
}

const RISKY_PERMISSIONS = ['READ_SMS', 'SEND_SMS', 'READ_CALL_LOG', 'RECORD_AUDIO', 'CAMERA', 'ACCESS_FINE_LOCATION', 'READ_CONTACTS', 'SYSTEM_ALERT_WINDOW', 'REQUEST_INSTALL_PACKAGES'];

/** App Guard - installed app risk analysis (permissions-based). */
export function analyzeApp(app: {
  name: string;
  packageName: string;
  permissions: string[];
  source?: 'play' | 'sideload';
}): ScanResult {
  let score = 0;
  const reasons: string[] = [];

  const risky = app.permissions.filter((p) => RISKY_PERMISSIONS.includes(p));
  if (risky.length >= 4) {
    score += 30;
    reasons.push(`${risky.length} high-risk permissions requested (${risky.slice(0, 3).join(', ')}...)`);
  } else if (risky.length >= 2) {
    score += 18;
    reasons.push(`${risky.length} sensitive permissions requested`);
  }
  if (app.source === 'sideload') {
    score += 25;
    reasons.push('Installed from outside the Play Store (sideloaded)');
  }
  if (app.permissions.includes('REQUEST_INSTALL_PACKAGES') && app.permissions.includes('READ_SMS')) {
    score += 20;
    reasons.push('Can silently install other apps + read SMS - classic malware behaviour');
  }
  if (/\.(apk|mod|hack|crack)/i.test(app.packageName)) {
    score += 15;
    reasons.push('Package name indicates a modified/cracked build');
  }

  score = Math.min(100, score);
  return { risk: riskFromScore(score), score, reasons };
}

export const RISK_COLORS: Record<RiskLevel, string> = {
  high: '#FF1744',
  medium: '#FF9100',
  low: '#FFD600',
  safe: '#00E676',
};

export const RISK_LABELS: Record<RiskLevel, string> = {
  high: 'HIGH RISK',
  medium: 'MEDIUM RISK',
  low: 'LOW RISK',
  safe: 'SAFE',
};
