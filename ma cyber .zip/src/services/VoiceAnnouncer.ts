/**
 * MA CYBER SHIELD - Voice Announcement Service
 * Uses Expo Speech (Text-to-Speech). No RECORD_AUDIO needed.
 *
 * Exact warning messages required by the product spec.
 */
import * as Speech from 'expo-speech';

export type ThreatVoiceType =
  | 'link'
  | 'message'
  | 'download'
  | 'app'
  | 'web'
  | 'general';

export const VOICE_MESSAGES: Record<ThreatVoiceType, string> = {
  link: 'Suspicious link detected. This link has been blocked for your safety.',
  message: 'Scam message detected. Do not click any links.',
  download: 'Malicious file detected. The download has been blocked.',
  app: 'Risky app detected. Please review and uninstall if necessary.',
  web: 'Dangerous website blocked. This site may try to steal your data.',
  general: 'Warning. Potential threat detected on your device.',
};

/**
 * Speak a threat warning.
 * - Clear English voice, slightly slower + lower pitch for a serious tone
 * - Volume set to maximum so the warning is noticeable
 * - Stops any previous announcement first (never overlaps system sounds)
 * - Auto-stops when the utterance finishes (Speech handles this)
 */
export function announceThreat(type: ThreatVoiceType) {
  const message = VOICE_MESSAGES[type] || VOICE_MESSAGES.general;
  Speech.stop();
  Speech.speak(message, {
    language: 'en-US',
    rate: 0.92,
    pitch: 0.95,
    volume: 1.0,
  });
}

export function stopAnnouncements() {
  Speech.stop();
}
