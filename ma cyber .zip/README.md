# MA CYBER SHIELD

**24/7 DIGITAL PROTECTION** — Block Scams • Stop Phishing • Stay Safe

A complete mobile cybersecurity app built with React Native + Expo (TypeScript). Dark neon UI, on-device Threat Engine, persistent 24/7 foreground service, and spoken voice warnings for every blocked threat.

---

## 📱 BUILD THE APK FROM YOUR PHONE ONLY (no computer, no Android Studio)

Everything is built **for free in the cloud** by GitHub Actions. You only need the **GitHub mobile app** (or the GitHub website on your phone browser).

### Step 1 — Create a free GitHub account
Open `github.com` in your phone browser → **Sign up** (free).

### Step 2 — Create a new repository
1. Open the **GitHub mobile app** (or `github.com/new` on your phone browser)
2. Tap **+ → New repository**
3. Name it `ma-cyber-shield` → tap **Create repository** (keep it public — free tier builds public repos for free)

### Step 3 — Upload the project files
**Option A — GitHub web editor (easiest):**
1. In your new repo, tap **Add file → Create new file**
2. Create each file from this project (copy-paste the full contents):
   - `App.tsx`
   - `app.json`
   - `package.json`
   - `plugins/cyberShield.js`, `plugins/withDeviceAdmin.js`, `plugins/withAccessibility.js`, `plugins/withUsageStats.js`, `plugins/withForegroundService.js`, `plugins/withNotificationListener.js`, `plugins/withBootReceiver.js`
   - everything under `src/`
   - `.github/workflows/build-apk.yml`
3. Scroll down → **Commit new file** (repeat per file)

**Option B — Acode / Spck Editor (on-device IDE):**
1. Install **Acode** (F-Droid / Play Store) or **Spck Editor**
2. Create the same folder structure, paste every file
3. Connect the folder to a git repo: `git init` → `git remote add origin <your-repo-url>` → `git add .` → `git commit -m "MA CYBER SHIELD"` → `git push -u origin main`

### Step 4 — Enable GitHub Actions
1. Open your repo on your phone browser → **Actions** tab
2. If asked, tap **I understand my workflows, go ahead and enable them**

### Step 5 — Trigger the build
Push any commit (or edit a file and commit). The `build-apk.yml` workflow runs automatically:
- Node 18 + Java 17 (Zulu)
- `npx expo prebuild --platform android --clean` (runs all config plugins → generates native code)
- `./gradlew assembleDebug` with `-Xmx2048m -XX:MaxMetaspaceSize=512m` (no OOM)
- Produces an **auto-signed, installable APK** — no keystore needed

### Step 6 — Download & install the APK
1. Repo → **Actions** → latest workflow run → **Artifacts** → download `app-release.apk`
2. Open the downloaded file → install (allow "install from unknown sources" once)
3. Done — MA CYBER SHIELD is on your phone 🛡️

---

## 🏗 Project Structure

```
ma-cyber-shield/
├── App.tsx                      # App entry (fonts, providers, navigation)
├── app.json                     # Expo config + all native plugins registered
├── package.json
├── plugins/                     # Modular Expo Config Plugins (native Android)
│   ├── cyberShield.js           # Main plugin - composes all modules
│   ├── withForegroundService.js # 24/7 persistent service (SPECIAL_USE, directBootAware)
│   ├── withAccessibility.js     # Link/Web Guard URL interception service
│   ├── withNotificationListener.js # Message Guard SMS/notification scanner
│   ├── withBootReceiver.js      # Restarts protection after reboot
│   ├── withUsageStats.js        # PACKAGE_USAGE_STATS for App Guard
│   └── withDeviceAdmin.js       # Optional theft protection
├── src/
│   ├── theme/colors.ts          # Neon dark theme tokens
│   ├── components/              # Reusable UI (ShieldLogo, cards, toggles, charts...)
│   ├── context/AppContext.tsx   # Global state + AsyncStorage persistence
│   ├── services/
│   │   ├── ThreatEngine.ts      # On-device URL/SMS/file/app heuristics
│   │   └── VoiceAnnouncer.ts    # expo-speech threat warnings (EN)
│   ├── data/mockData.ts         # Seed alerts & history
│   ├── navigation/AppNavigator.tsx # Bottom tabs + stack
│   └── screens/                 # Home, Dashboard, 5 Guards, Alerts, History, Settings
└── .github/workflows/build-apk.yml # Free-tier cloud APK build
```

---

## 🛡 Features

- **Home** — glowing neon shield, "Protection Active" status card, live monitoring checklist
- **Dashboard** — Protected status + 24/7 badge, threats blocked today (+8% trend), 7-day bar chart, 2×2 guard grid (Link / Message / Download / App) + wide Web Guard card
- **5 Guard detail screens** — red threat-alert cards, BLOCKED badges, threat analysis, and a **live scanner** (paste any URL / message / file name / app name and run real on-device heuristics)
- **Voice Announcements** — every threat speaks a clear English warning via Expo Speech (TTS, no mic needed):
  - Link Guard → "Suspicious link detected. This link has been blocked for your safety."
  - Message Guard → "Scam message detected. Do not click any links."
  - Download Guard → "Malicious file detected. The download has been blocked."
  - App Guard → "Risky app detected. Please review and uninstall if necessary."
  - Web Guard → "Dangerous website blocked. This site may try to steal your data."
  - General → "Warning. Potential threat detected on your device."
  - Toggle in **Protection Settings** (ON by default)
- **Alerts tab** — notification-style threat cards, pull-to-refresh, clear-all, simulate button
- **History tab** — full threat log with risk dots, action badges, category filters
- **Protection Settings** — master switch, foreground service, auto-block, voice announcements, per-guard toggles, scan sensitivity (Low/Medium/High)
- **24/7 Protection flow** — Monitor → Analyze → Block/Warn → Keep You Safe
- **Required permissions checklist** — Usage Access, Notification Access, Accessibility, Storage, Internet, Device Admin (optional)

---

## ⚙️ Native Android (via Expo Config Plugins only)

All native configuration is injected by modular plugins in `plugins/` — registered in `app.json` and executed by `npx expo prebuild` in the cloud:

| Plugin | Injects |
|---|---|
| `withForegroundService` | `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE`, `ShieldForegroundService` (`foregroundServiceType="specialUse"`, `directBootAware`, `START_STICKY`, survives swipe-away) |
| `withAccessibility` | `BIND_ACCESSIBILITY_SERVICE` + `ShieldAccessibilityService` (Link/Web Guard interception) |
| `withNotificationListener` | `BIND_NOTIFICATION_LISTENER_SERVICE` + scam-keyword notification scanner (Message Guard) |
| `withBootReceiver` | `RECEIVE_BOOT_COMPLETED` + `LOCKED_BOOT_COMPLETED` receiver that restarts the service after reboot |
| `withUsageStats` | `PACKAGE_USAGE_STATS` (App Guard risk analysis) |
| `withDeviceAdmin` | Optional `ShieldDeviceAdminReceiver` (remote lock/wipe) |

Android 13/14/15 compliant: every `<service>` has explicit `android:exported`, foreground service declares `FOREGROUND_SERVICE_SPECIAL_USE` + `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`, and boot-aware components set `android:directBootAware="true"`.

**RECORD_AUDIO is NOT required** — voice warnings use Text-to-Speech only.

---

## 🔁 Cloud APK Builds (GitHub Actions, free tier)

`.github/workflows/build-apk.yml` runs on every push:

1. Node 18 + Java 17 (Zulu), npm cache
2. `npm ci`
3. `npx expo prebuild --platform android --clean` (generates native code via the config plugins)
4. `./gradlew assembleDebug` with `GRADLE_OPTS="-Dorg.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m"` (OOM-safe)
5. Uploads `app-release.apk` as a workflow artifact — download it from the Actions tab

No keystores, no base64 secrets, no paid runners. The debug APK is auto-signed and installable.

---

## 📄 License

MIT — MA CYBER SHIELD. Your Security. Our Mission.
**BEFORE IT HAPPENS, WE STOP IT.**
